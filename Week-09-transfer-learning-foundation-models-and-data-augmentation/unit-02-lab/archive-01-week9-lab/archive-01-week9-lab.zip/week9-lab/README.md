# Week 9 Lab: Adapt, Do Not Rebuild

**AI Principles and Practice · SETU**

A small network was trained on 900 clean scanned digits. It stands in for a pretrained model. Your new job:
digits from a cheap, noisy scanner, with only 5 labelled examples of each digit. Do you start again, or reuse
what the network already knows?

Six exercises, following the lecture: *reuse* (1 and 2), *adapt* (3), *augment* (4), *count the cost* (5), and
your capstone (6). In each one you **predict** before you run, **run** the cell, **look** at the printout the
question names, and **explain** in your own words. In Exercises 3, 4 and 5 you **build** a small piece yourself.

| Exercise | Lecture | Slides | You build | Time |
|---|---|---|---|---|
| 1 · Reuse it as it is | Parts 1 and 2 | 5 to 10, 13 | | 15 min |
| 2 · From scratch, or reused? | Part 1 | 5 and 6 | | 20 min |
| 3 · Adapt three ways | Part 2 | 12 to 22 | `my_lora_weight`, `my_lora_count` | 25 min |
| 4 · Augment, do not label | Part 3 | 24 to 28 | `my_augment` | 20 min |
| 5 · Count the cost | Part 4 | 30 to 33 | `my_energy_kwh`, `my_carbon_kg` | 15 min |
| 6 · Your capstone | Wrap-up | 35 | | 10 min |
| | Two last questions, then submit | | | 10 min |

About 2 h. **If any exercise takes more than 40 minutes, stop and post in the channel.**

## What you need

Python 3.10 or newer with the packages in `requirements.txt`. **No PyTorch**: everything runs in NumPy in a few
seconds, on any laptop. Or Google Colab.

```bash
pip install -r requirements.txt
jupyter notebook week9_lab.ipynb
```

## The files

| file | what it is | do I need it? |
|---|---|---|
| `week9_lab.ipynb` | **The lab.** Open this. | **yes** |
| `SUBMISSION.md` | **The answer sheet, blank.** Fill it in as you go, add your name. | **yes** |
| `WHERE_TO_FIND.md` | For each question, which cell to run and which printout to read. | **yes** |
| `lecture_steps.py` | The backbone, the noisy scanner, one helper per lecture idea, and the checks. Never edit it. | no |

## Submitting

Upload `SUBMISSION.md`, named `week09-<student number>-SUBMISSION.md`, using the link on the Submit page. Labs
are not graded this week: submitting is how you show you did the work. Then compare with the Week 9 Reference Answers.
