# Week 9 Lab: Submission

**Name:**   **Student number:**   **My capstone elective:**

> **This sheet is blank on purpose.** Fill it in as you go. Each question is one of five kinds:
> **Predict** (write it *before* you run the cell, and do not change it afterwards), **Record** (the numbers from
> the printout named), **Explain** (two or three sentences in your own words), **Build** (paste the code that
> passed its check) and **Change** (predict, change one thing, say what happened).

---

## Exercise 1 · Reuse it as it is  *(slides 5 to 10, 13)*

**1a · Predict.** On the noisy scanner, with no new training: about 95%, about 70%, or about 30%?

**1b · Record and explain.** Printout A: clean and noisy accuracy. Why does accuracy drop so much when only the scanner changed?

---

## Exercise 2 · From scratch, or reused?  *(slides 5 and 6)*

**2a · Predict.** With 5 labels per digit: does scratch beat the reused backbone, tie, or lose?

**2b · Record and explain.** Printout B: both accuracies. Why does scratch do so badly with 50 examples?

**2c · Predict.** Labels per digit scratch needs to roughly catch up: about 5, about 20, or about 1,000?

**2d · Record and explain.** Table C: when is reusing worth most, and when least?

---

## Exercise 3 · Adapt three ways  *(slides 12 to 22)*

**3a · Build.** Your two lines:

```python

```

**3b · Predict.** Rank probe, LoRA and fine-tuning by accuracy, and by numbers trained.

**3c · Record and explain.** Table D. Is fine-tuning's extra accuracy worth five times as many numbers? Which would you choose for a model with a billion numbers, and why?

---

## Exercise 4 · Augment, do not label  *(slides 24 to 28)*

**4a · Build.** Your `copies = ...` line:

```python

```

**4b · Predict.** Will noisy copies beat 71% on the noisy scanner? What will upside-down copies do?

**4c · Record and explain.** Table E. What invariance did your noisy copies teach, and why do upside-down copies make things worse?

---

## Exercise 5 · Count the cost  *(slides 30 to 33)*

**5a · Build.** Your two lines:

```python

```

**5b · Predict.** How many times more calculations did GPT-3 need than our backbone: a thousand, a billion, or a hundred trillion?

**5c · Record and explain.** Printout F. Two reasons, beyond accuracy, to prefer LoRA or a probe over full fine-tuning of a large model.

---

## Exercise 6 · Your capstone  *(slide 35)*

**6a.** For your elective: which point on the transfer spectrum would you start from, and why?

**6b.** One augmentation that encodes a true invariance in your capstone data, and one that would teach a wrong lesson.

---

## Two last questions

**L1.** In one sentence each: what is a linear probe, what is LoRA, and what does augmentation teach a model?

**L2.** Which prediction today was furthest off, and what do you think now?
