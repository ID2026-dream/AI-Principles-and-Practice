# Week 9 Lab: which cell to run, and which printout to read, for each question

Predict questions are answered **before** the cell they point at. Build questions need their check cell to show ✓
on every line.

| Exercise | Slides | Run | Read | Questions |
|---|---|---|---|---|
| 1 | 5 to 10, 13 | `ls.show_scanner()`, `ls.zero_shot()` | Printout A | 1a predict · 1b Printout A |
| 2 | 5 and 6 | `ls.scratch_or_reuse()`, `ls.labels_table()` | Printout B, Table C | 2a, 2c predict · 2b Printout B · 2d Table C |
| 3 | 12 to 22 | your two LoRA functions + `ls.check_my_lora`, `ls.three_ways()` | the check, Table D | 3a build · 3b predict · 3c Table D |
| 4 | 24 to 28 | your `my_augment` + `ls.check_my_augment`, `ls.augment_table()` and `ls.pretrain_with(my_augment, ...)` | the check, Table E | 4a build · 4b predict · 4c Table E |
| 5 | 30 to 33 | your two cost functions + `ls.check_my_carbon`, `ls.cost_table(...)` | the check, Printout F | 5a build · 5b predict · 5c Printout F |
| 6 | 35 | (no code) | your capstone brief | 6a, 6b |
