"""lecture_steps.py — Week 9: one helper per lecture idea, and the checks for the code you write.

The story: a small network trained on 900 clean scanned digits (our stand-in for a pretrained
model) is reused for a new job: digits from a cheap, noisy scanner, with only a few labels.
Everything runs in NumPy in a second or two. You never need to edit or open this file.
"""
import os
import time
import warnings

import numpy as np
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
os.makedirs("figures", exist_ok=True)
SIZES = [64, 64, 32, 10]          # 64 pixels → 64 → 32 → 10 digits


def _ok(m):
    print(f"  ✓ {m}")


def _no(m):
    print(f"  ✗ {m}")


# ============================================================ the network (NumPy)
def init(sizes, seed=0):
    rng = np.random.default_rng(seed)
    return ([rng.normal(0, np.sqrt(2 / m), (m, n)) for m, n in zip(sizes[:-1], sizes[1:])],
            [np.zeros((1, n)) for n in sizes[1:]])


def _softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


def _weights(W, lora):
    return [W[i] + (lora[i][0] @ lora[i][1] if lora is not None and lora[i] is not None else 0) for i in range(len(W))]


def forward(X, W, b, lora=None):
    Ws = _weights(W, lora)
    h, z = [X], []
    for i in range(len(Ws)):
        zi = h[-1] @ Ws[i] + b[i]
        z.append(zi)
        h.append(_softmax(zi) if i == len(Ws) - 1 else np.maximum(0, zi))
    return h, z


def _grads(X, y, W, b, lora=None):
    Ws = _weights(W, lora)
    h, z = forward(X, W, b, lora)
    delta = (h[-1] - np.eye(10)[y]) / len(X)
    gW, gb = [None] * len(W), [None] * len(W)
    for i in reversed(range(len(W))):
        gW[i] = h[i].T @ delta
        gb[i] = delta.sum(0, keepdims=True)
        if i > 0:
            delta = (delta @ Ws[i].T) * (z[i - 1] > 0)
    return gW, gb


def accuracy(X, y, W, b, lora=None):
    return float((forward(X, W, b, lora)[0][-1].argmax(1) == y).mean())


class _Adam:
    def __init__(self, params, lr):
        self.p, self.lr, self.t = params, lr, 0
        self.m = [np.zeros_like(x) for x in params]
        self.v = [np.zeros_like(x) for x in params]

    def step(self, g):
        self.t += 1
        for p, gi, m, v in zip(self.p, g, self.m, self.v):
            m *= 0.9; m += 0.1 * gi
            v *= 0.999; v += 0.001 * gi * gi
            p -= self.lr * (m / (1 - 0.9 ** self.t)) / (np.sqrt(v / (1 - 0.999 ** self.t)) + 1e-8)


def _pretrain(X, y, epochs=60, seed=0):
    W, b = init(SIZES, seed)
    opt = _Adam(W + b, 0.005)
    rng = np.random.default_rng(seed)
    for _ in range(epochs):
        order = rng.permutation(len(X))
        for s in range(0, len(X), 32):
            i = order[s:s + 32]
            gW, gb = _grads(X[i], y[i], W, b)
            opt.step(gW + gb)
    return W, b


# ============================================================ the data
def _digits():
    from sklearn.datasets import load_digits
    D = load_digits()
    X, y = D.data / 16.0, D.target
    idx = np.random.default_rng(0).permutation(len(X))
    return X, y, idx[:900], idx[900:]


def noisy_copy(X, seed=0, noise=0.25, blot=2):
    """What the cheap scanner does: grainy noise, plus one bright blot on each digit."""
    rng = np.random.default_rng(seed)
    imgs = (X + rng.normal(0, noise, X.shape)).reshape(-1, 8, 8).copy()
    for k in range(len(imgs)):
        i, j = rng.integers(0, 8 - blot + 1, 2)
        imgs[k, i:i + blot, j:j + blot] = 1.0
    return np.clip(imgs.reshape(-1, 64), 0, 1.2)


def upside_down(X):
    """Turn every digit upside down."""
    return X.reshape(-1, 8, 8)[:, ::-1, ::-1].reshape(-1, 64)


_X, _Y, _SRC, _TGT = _digits()
CLEAN_X, CLEAN_Y = _X[_SRC], _Y[_SRC]                    # the backbone's training data: 900 clean digits
TARGET_CLEAN = _X[_TGT]
TARGET_X, TARGET_Y = noisy_copy(_X[_TGT], seed=1), _Y[_TGT]  # the new job: the noisy scanner
BACKBONE = _pretrain(CLEAN_X, CLEAN_Y)


def few_labels(k=5, seed=0):
    """k labelled examples of each digit from the noisy scanner, and the rest for testing."""
    rng = np.random.default_rng(seed)
    tr = np.concatenate([rng.choice(np.where(TARGET_Y == c)[0], k, replace=False) for c in range(10)])
    te = np.setdiff1d(np.arange(len(TARGET_Y)), tr)
    return TARGET_X[tr], TARGET_Y[tr], TARGET_X[te], TARGET_Y[te]


def adapt(mode, k=5, seed=0, rank=4):
    """Adapt the backbone with k labels per digit. mode: scratch | probe | finetune | lora.
    Returns (test accuracy, trainable numbers, seconds)."""
    Xtr, ytr, Xte, yte = few_labels(k, seed)
    rng = np.random.default_rng(seed)
    W = [w.copy() for w in BACKBONE[0]]
    b = [x.copy() for x in BACKBONE[1]]
    lora = None
    if mode == "scratch":
        W, b = init(SIZES, seed + 1)
        params, lr, epochs = W + b, 0.01, 300
    elif mode == "probe":
        params, lr, epochs = [W[-1], b[-1]], 0.005, 200
    elif mode == "finetune":
        params, lr, epochs = W + b, 0.005, 200
    elif mode == "lora":
        lora = [[np.zeros((W[i].shape[0], rank)), rng.normal(0, 0.01, (rank, W[i].shape[1]))] for i in range(len(W) - 1)] + [None]
        params, lr, epochs = [W[-1], b[-1]] + [x for p in lora[:-1] for x in p], 0.005, 200
    else:
        raise ValueError(mode)
    trainable = int(sum(p.size for p in params))
    opt = _Adam(params, lr)
    t0 = time.perf_counter()
    for _ in range(epochs):
        gW, gb = _grads(Xtr, ytr, W, b, lora)
        if mode in ("scratch", "finetune"):
            g = gW + gb
        elif mode == "probe":
            g = [gW[-1], gb[-1]]
        else:
            g = [gW[-1], gb[-1]]
            for i in range(len(W) - 1):
                g += [gW[i] @ lora[i][1].T, lora[i][0].T @ gW[i]]
        opt.step(g)
    secs = time.perf_counter() - t0
    return accuracy(Xte, yte, W, b, lora), trainable, secs


def _mean_adapt(mode, k, seeds=(0, 1, 2)):
    out = [adapt(mode, k, s) for s in seeds]
    return float(np.mean([o[0] for o in out])), out[0][1], float(np.mean([o[2] for o in out]))


# ============================================================ Exercise 1 · reuse as it is
def show_scanner():
    fig, axes = plt.subplots(2, 6, figsize=(9, 3.4))
    for j in range(6):
        axes[0, j].imshow(TARGET_CLEAN[j].reshape(8, 8), cmap="gray_r", vmin=0, vmax=1)
        axes[1, j].imshow(TARGET_X[j].reshape(8, 8), cmap="gray_r", vmin=0, vmax=1)
        for a in axes[:, j]:
            a.set_xticks([]); a.set_yticks([])
    axes[0, 0].set_ylabel("clean"); axes[1, 0].set_ylabel("noisy scanner")
    plt.tight_layout(); plt.savefig("figures/01_scanner.png", dpi=110); plt.show()


def zero_shot():
    W, b = BACKBONE
    print("Printout A: the backbone, used as it is (no new training)")
    print(f"  on clean digits it has never seen:       {accuracy(TARGET_CLEAN, TARGET_Y, W, b):.1%}")
    print(f"  on the same digits from the noisy scanner: {accuracy(TARGET_X, TARGET_Y, W, b):.1%}")


# ============================================================ Exercise 2 · from scratch or reused
def scratch_or_reuse(k=5):
    print(f"Printout B: {k} labels per digit ({10 * k} in all) from the noisy scanner")
    for mode, name in (("scratch", "a new network, trained from scratch"), ("probe", "the backbone, with a new final layer")):
        acc, n, _ = _mean_adapt(mode, k)
        print(f"  {name:<40} {acc:.1%}")


def labels_table(ks=(1, 2, 5, 10, 20, 40)):
    print("Table C: accuracy on the noisy scanner, by labels per digit")
    print(f"  {'labels per digit':>17}   {'from scratch':>12}   {'reused + fine-tuned':>19}")
    for k in ks:
        a1 = _mean_adapt("scratch", k)[0]
        a2 = _mean_adapt("finetune", k)[0]
        print(f"  {k:>17}   {a1:>12.1%}   {a2:>19.1%}")


# ============================================================ Exercise 3 · adapt three ways (build)
def check_my_lora(my_lora_weight, my_lora_count):
    print("Check: my_lora_weight and my_lora_count")
    rng = np.random.default_rng(0)
    W, B, A = rng.normal(size=(6, 5)), rng.normal(size=(6, 2)), rng.normal(size=(2, 5))
    try:
        out = my_lora_weight(W, B, A)
    except Exception as e:
        _no(f"my_lora_weight raised {type(e).__name__}: {e}")
        return
    if out is None:
        _no("my_lora_weight returns None. Replace None with your line.")
        return
    if np.shape(out) != (6, 5):
        _no(f"my_lora_weight should return a 6 × 5 table, like W; yours is {np.shape(out)}. Use B @ A.")
        return
    if not np.allclose(out, W + B @ A):
        _no("my_lora_weight is not W + B @ A.")
        return
    _ok("my_lora_weight(W, B, A) = W + B @ A")
    try:
        c = my_lora_count(768, 768, 8)
    except Exception as e:
        _no(f"my_lora_count raised {type(e).__name__}: {e}")
        return
    if c is None:
        _no("my_lora_count returns None. Replace None with your line.")
        return
    if c != 12288:
        _no(f"my_lora_count(768, 768, 8) should be 12,288 (768 × 8 + 8 × 768); yours is {c}.")
        return
    _ok("my_lora_count(768, 768, 8) = 12,288")
    if my_lora_count(64, 64, 4) != 512:
        _no("my_lora_count(64, 64, 4) should be 512.")
        return
    _ok("my_lora_count(64, 64, 4) = 512")
    print("  All correct.")


def three_ways(k=5):
    print(f"Table D: three ways to adapt the backbone, {k} labels per digit (averaged over 3 runs)")
    print(f"  {'way':<34} {'accuracy':>9} {'numbers trained':>16} {'seconds':>8}")
    rows = (("probe", "new final layer only (linear probe)"), ("lora", "LoRA, rank 4, + final layer"), ("finetune", "fine-tune everything"))
    for mode, name in rows:
        acc, n, sec = _mean_adapt(mode, k)
        print(f"  {name:<34} {acc:>9.1%} {n:>16,} {sec:>8.2f}")
    print("  (For comparison, the whole network has 6,570 numbers.)")


# ============================================================ Exercise 4 · augment (build)
def check_my_augment(my_augment):
    print("Check: my_augment")
    try:
        Xa, ya = my_augment(CLEAN_X[:20], CLEAN_Y[:20])
    except Exception as e:
        _no(f"my_augment raised {type(e).__name__}: {e}")
        return
    if Xa is None or ya is None:
        _no("my_augment returns None. Fill in the line.")
        return
    Xa, ya = np.asarray(Xa), np.asarray(ya)
    if len(Xa) != len(ya):
        _no(f"you return {len(Xa)} images but {len(ya)} labels: repeat the labels once for each copy.")
        return
    if len(Xa) < 40:
        _no("you return no extra copies: stack the originals with at least one noisy copy.")
        return
    if not np.allclose(Xa[:20], CLEAN_X[:20]):
        _no("the first rows should be the original digits.")
        return
    _ok(f"{len(Xa) // 20 - 1} extra cop{'y' if len(Xa) // 20 == 2 else 'ies'} of every digit, labels repeated to match")
    print("  All correct.")


def pretrain_with(my_augment, name="your augmentation"):
    try:
        Xa, ya = my_augment(CLEAN_X, CLEAN_Y)
        assert Xa is not None and ya is not None and len(Xa) == len(ya)
    except Exception:
        print("  ✗ Finish Exercise 4 first: its check must show ✓, then run this cell again.")
        return
    W, b = _pretrain(np.asarray(Xa), np.asarray(ya))
    _augment_row(name, W, b)


def _augment_row(name, W, b):
    p_clean = forward(TARGET_CLEAN, W, b)[0][-1].argmax(1)
    p_noisy = forward(TARGET_X, W, b)[0][-1].argmax(1)
    print(f"  {name:<30} clean {np.mean(p_clean == TARGET_Y):6.1%}   noisy scanner {np.mean(p_noisy == TARGET_Y):6.1%}")


def augment_table():
    print("Table E: the same backbone, trained on different copies of the same 900 clean digits (no new labels)")
    _augment_row("clean digits only", *BACKBONE)
    Xa = np.vstack([CLEAN_X, upside_down(CLEAN_X)]); ya = np.tile(CLEAN_Y, 2)
    _augment_row("+ upside-down copies", *_pretrain(Xa, ya))


# ============================================================ Exercise 5 · count the cost (build)
def check_my_carbon(my_energy_kwh, my_carbon_kg):
    print("Check: my_energy_kwh and my_carbon_kg")
    tests = [("my_energy_kwh(300, 10)", lambda: my_energy_kwh(300, 10), 3.0),
             ("my_energy_kwh(1000, 1)", lambda: my_energy_kwh(1000, 1), 1.0),
             ("my_carbon_kg(3.0, 0.3)", lambda: my_carbon_kg(3.0, 0.3), 0.9)]
    for name, f, want in tests:
        try:
            got = f()
        except Exception as e:
            _no(f"{name} raised {type(e).__name__}: {e}")
            return
        if got is None:
            _no(f"{name} returns None. Replace None with your line.")
            return
        if abs(float(got) - want) > 1e-9:
            hint = " Divide watts by 1,000 to get kilowatts." if abs(float(got) - want * 1000) < 1e-6 else ""
            _no(f"{name} should be {want}, yours is {got}.{hint}")
            return
        _ok(f"{name} = {want}")
    print("  All correct.")


def cost_table(my_energy_kwh, my_carbon_kg):
    try:
        assert my_energy_kwh(300, 10) is not None and my_carbon_kg(3.0, 0.3) is not None
    except Exception:
        print("  ✗ Finish the Exercise 5 build first: its check must show ✓, then run this cell again.")
        return
    print("Printout F: compute and carbon, from tiny to huge")
    ours = 6 * 6570 * 900 * 60
    gpt3 = 6 * 175e9 * 300e9
    print(f"  our backbone:  6 × 6,570 numbers × 900 digits × 60 passes ≈ {ours:.1e} calculations")
    print(f"  GPT-3:         6 × 175 billion × 300 billion words      ≈ {gpt3:.1e} calculations")
    print(f"  GPT-3 needed about {gpt3 / ours:.0e} times more.")
    e = my_energy_kwh(300, 10)
    print(f"  one 300 W graphics card for 10 hours: {e:.1f} kWh, about {my_carbon_kg(e, 0.3):.1f} kg of CO₂ (at 0.3 kg per kWh)")
    print("  GPT-3's training, as published: about 1,287,000 kWh and 552 tonnes of CO₂ (Patterson and others, 2021)")
