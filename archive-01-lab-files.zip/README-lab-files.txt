Week 3 lab files — AI Principles and Practice

UCI_Credit_Card.csv   Default of Credit Card Clients (Yeh & Lien, 2009),
                      UCI Machine Learning Repository,
                      https://doi.org/10.24432/C55S3H, CC BY 4.0.
                      30,000 clients of a Taiwanese bank, Apr-Sep 2005.
                      The same file as Weeks 1 and 2. This week the Week 2
                      default classifier is retrained without SEX and
                      audited for fairness across it.

Put it in your Week 3 lab folder, then unzip the Week 03 Submission Kit
beside it.

  pip install numpy pandas scikit-learn scipy matplotlib fairlearn
