# Supplementary notes: source

Source for *Correlation and Data Augmentation*, the Week 1 supplementary notes.

## Contents

| File | What it is |
|---|---|
| `notes.tex` | the full document |
| `figures.py` | seeded script producing every figure |
| `fig_*.png` | the generated figures, so the PDF builds without rerunning Python |

## Rebuilding

```bash
pip install numpy scipy pandas matplotlib scikit-learn imbalanced-learn dcor
python3 figures.py          # regenerates the four figures
pdflatex notes.tex && pdflatex notes.tex   # twice, for the contents and cross-references
```

Requires a TeX distribution with `mathpazo`, `tcolorbox`, `titlesec`, `listings` and `tabularx`.

Everything is seeded. Change one parameter at a time and rerun, which is the
same habit `make_assets.py` is meant to encourage.
