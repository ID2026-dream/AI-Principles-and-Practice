"""Figures for the Week 1 supplementary notes: Correlation and Data Augmentation."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
import dcor

NAVY = "#2f4a68"
BLUE = "#7b9bd1"
RED = "#b5432a"
GREEN = "#2b7a5c"
GREY = "#8d949c"

plt.rcParams.update({
    "figure.dpi": 200,
    "font.size": 8.5,
    "axes.edgecolor": "#b8bec5",
    "axes.labelcolor": NAVY,
    "axes.titlecolor": NAVY,
    "xtick.color": "#5a6470",
    "ytick.color": "#5a6470",
    "axes.grid": True,
    "grid.color": "#e3e7ec",
    "grid.linewidth": 0.6,
    "axes.axisbelow": True,
})

rng = np.random.default_rng(7)


def chatterjee_xi(x, y, rng=rng):
    """Chatterjee (2021) rank correlation xi. Asymmetric: measures how far Y is a function of X."""
    n = len(x)
    jitter = rng.random(n) * 1e-9
    order = np.argsort(x + jitter)
    r = stats.rankdata(y[order], method="max")
    return 1.0 - 3.0 * np.abs(np.diff(r)).sum() / (n ** 2 - 1)


def annotate(ax, x, y):
    r = stats.pearsonr(x, y)[0]
    rho = stats.spearmanr(x, y)[0]
    tau = stats.kendalltau(x, y)[0]
    dc = dcor.distance_correlation(x, y)
    xi = chatterjee_xi(x, y)
    txt = (f"Pearson r   = {r:+.2f}\n"
           f"Spearman    = {rho:+.2f}\n"
           f"Kendall     = {tau:+.2f}\n"
           f"dCor        = {dc:.2f}\n"
           f"Chatterjee  = {xi:.2f}")
    ax.text(0.03, 0.97, txt, transform=ax.transAxes, va="top", ha="left",
            family="DejaVu Sans Mono", fontsize=6.6, color=NAVY,
            bbox=dict(boxstyle="round,pad=0.35", fc="#f7f9fb", ec="#ccd3da", lw=0.6))


# ---------------------------------------------------------------- figure 1
def fig_panels(path):
    n = 300
    cases = {}

    x = rng.uniform(-3, 3, n)
    cases["Linear with noise"] = (x, 1.2 * x + rng.normal(0, 1.0, n))

    x = rng.uniform(0, 3, n)
    cases["Monotone, strongly curved"] = (x, np.exp(x) + rng.normal(0, 1.0, n))

    x = rng.uniform(-3, 3, n)
    cases["Symmetric U shape"] = (x, x ** 2 + rng.normal(0, 0.8, n))

    x = rng.uniform(0, 4 * np.pi, n)
    cases["Periodic"] = (x, np.sin(x) + rng.normal(0, 0.18, n))

    x = np.concatenate([rng.normal(0, 1, n - 6), rng.normal(9, 0.4, 6)])
    y = np.concatenate([rng.normal(0, 1, n - 6), rng.normal(9, 0.4, 6)])
    cases["No trend plus six outliers"] = (x, y)

    x = rng.uniform(0, 4, n)
    cases["Heteroscedastic fan"] = (x, rng.normal(0, 0.25 + 0.75 * x))

    fig, axes = plt.subplots(2, 3, figsize=(9.6, 5.6))
    for ax, (title, (x, y)) in zip(axes.ravel(), cases.items()):
        ax.scatter(x, y, s=7, color=BLUE, alpha=0.75, linewidths=0)
        ax.set_title(title, fontsize=8.5, weight="bold", pad=6)
        annotate(ax, x, y)
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.tick_params(length=0)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- figure 2
def fig_simpson(path):
    """Within each plan, longer tenure lowers monthly charge. Pooled, it appears to raise it."""
    groups = [("Basic", 11, 22, BLUE), ("Standard", 29, 40, GREEN), ("Premium", 48, 62, RED)]
    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.5))
    allx, ally = [], []
    for name, tmid, cmid, col in groups:
        t = np.clip(rng.normal(tmid, 4.5, 120), 0, 71)
        c = cmid - 0.55 * (t - tmid) + rng.normal(0, 2.2, 120)
        allx.append(t); ally.append(c)
        for ax in axes:
            ax.scatter(t, c, s=9, color=col, alpha=0.7, linewidths=0,
                       label=name if ax is axes[0] else None)
        r = stats.pearsonr(t, c)[0]
        sl, ic = np.polyfit(t, c, 1)
        xs = np.linspace(t.min(), t.max(), 10)
        axes[0].plot(xs, sl * xs + ic, color=col, lw=1.8)
        axes[0].text(t.mean(), cmid + 11, f"{name}: r = {r:+.2f}",
                     color=col, fontsize=7.5, ha="center", weight="bold")

    X = np.concatenate(allx); Y = np.concatenate(ally)
    sl, ic = np.polyfit(X, Y, 1)
    xs = np.linspace(X.min(), X.max(), 10)
    axes[1].plot(xs, sl * xs + ic, color=NAVY, lw=2.4, ls="--")
    axes[1].text(0.03, 0.95, f"pooled r = {stats.pearsonr(X, Y)[0]:+.2f}",
                 transform=axes[1].transAxes, va="top", color=NAVY,
                 fontsize=8.5, weight="bold")

    axes[0].set_title("Within each plan, the slope is negative", fontsize=9, weight="bold")
    axes[1].set_title("Pool the plans and the slope flips positive", fontsize=9, weight="bold")
    for ax in axes:
        ax.set_xlabel("tenure (months)")
        ax.set_ylabel("monthly charge")
    axes[0].legend(frameon=False, fontsize=7.5, loc="lower right")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- figure 3
def fig_resamplers(path):
    from sklearn.datasets import make_classification
    from imblearn.over_sampling import (RandomOverSampler, SMOTE,
                                        BorderlineSMOTE, ADASYN)
    X, y = make_classification(n_samples=900, n_features=2, n_redundant=0,
                               n_informative=2, n_clusters_per_class=1,
                               weights=[0.93, 0.07], flip_y=0.02,
                               class_sep=1.0, random_state=4)
    samplers = [("Original", None),
                ("Random oversampling", RandomOverSampler(random_state=0)),
                ("SMOTE", SMOTE(random_state=0)),
                ("Borderline-SMOTE", BorderlineSMOTE(random_state=0)),
                ("ADASYN", ADASYN(random_state=0))]
    fig, axes = plt.subplots(1, 5, figsize=(12.6, 2.9))
    for ax, (name, samp) in zip(axes, samplers):
        Xs, ys = (X, y) if samp is None else samp.fit_resample(X, y)
        ax.scatter(Xs[ys == 0, 0], Xs[ys == 0, 1], s=5, color=BLUE, alpha=0.45, linewidths=0)
        ax.scatter(Xs[ys == 1, 0], Xs[ys == 1, 1], s=7, color=RED, alpha=0.75, linewidths=0)
        ax.set_title(f"{name}\nminority n = {(ys == 1).sum()}", fontsize=8, weight="bold")
        ax.set_xticklabels([]); ax.set_yticklabels([]); ax.tick_params(length=0)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- figure 4
def fig_smote_leak(path):
    from sklearn.model_selection import cross_val_score, StratifiedKFold
    from sklearn.ensemble import RandomForestClassifier
    from imblearn.over_sampling import SMOTE
    from imblearn.pipeline import Pipeline as ImbPipeline

    n, p = 500, 25
    X = rng.normal(size=(n, p))                 # pure noise
    y = (rng.random(n) < 0.12).astype(int)      # labels unrelated to X
    cv = StratifiedKFold(5, shuffle=True, random_state=0)
    clf = lambda: RandomForestClassifier(n_estimators=200, random_state=0, n_jobs=-1)

    Xr, yr = SMOTE(random_state=0).fit_resample(X, y)
    leaked = cross_val_score(clf(), Xr, yr, cv=cv, scoring="roc_auc").mean()

    pipe = ImbPipeline([("smote", SMOTE(random_state=0)), ("clf", clf())])
    honest = cross_val_score(pipe, X, y, cv=cv, scoring="roc_auc").mean()

    fig, ax = plt.subplots(figsize=(6.0, 3.2))
    labels = ["SMOTE applied to all\nrows, then cross-validate",
              "SMOTE inside an\nimblearn Pipeline",
              "Chance"]
    vals = [leaked, honest, 0.5]
    cols = [RED, GREEN, "#aab6c4"]
    bars = ax.bar(labels, vals, color=cols, width=0.6)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.015, f"{v:.2f}",
                ha="center", fontsize=9.5, weight="bold", color=NAVY)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("5-fold cross-validated ROC AUC")
    ax.set_title("Labels are random. Any score above 0.5 is manufactured.",
                 fontsize=9, weight="bold")
    ax.tick_params(axis="x", labelsize=7.5)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return leaked, honest


if __name__ == "__main__":
    fig_panels("fig_corr_panels.png")
    fig_simpson("fig_simpson.png")
    fig_resamplers("fig_resamplers.png")
    print(fig_smote_leak("fig_smote_leak.png"))
    print("done")
