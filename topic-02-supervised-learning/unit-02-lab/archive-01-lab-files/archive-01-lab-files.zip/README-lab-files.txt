Week 2 lab files — AI Principles and Practice

UCI_Credit_Card.csv   Default of Credit Card Clients (Yeh & Lien, 2009),
                      UCI Machine Learning Repository,
                      https://doi.org/10.24432/C55S3H, CC BY 4.0.
                      30,000 clients of a Taiwanese bank, Apr-Sep 2005.
                      The same file as Week 1. Modelled this week, and
                      audited for fairness in Week 3.

Put it in your Week 2 lab folder, then unzip the Week 02 Submission Kit
beside it.

  pip install numpy pandas scikit-learn matplotlib
