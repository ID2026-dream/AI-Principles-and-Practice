Week 3 lab submission kit — AI Principles and Practice
======================================================

Unzip this into the same folder as your Week 3 lab work, so that it sits
alongside UCI_Credit_Card.csv from the Week 03 Lab Files archive.

  SUBMISSION.md        Your answers. Fill it in and delete each TODO.
  make_submission.py   Builds the single zip you upload. Run it last.
  setup_check.py       Environment report. Run it before the lab.
                       This week it also checks for fairlearn.

Three steps, the same every week:

  1. Answer SUBMISSION.md as you work through Sections 1 to 7
  2. python make_submission.py
  3. Upload the one zip it names to the OneDrive folder on the course site

Keep your code and plots in this folder as you write them
(section1_metricframe.py, section5_impossibility.py, cal_by_group.png, a
notebook — whatever you used). They go into the zip automatically. The
provided UCI_Credit_Card.csv does not.

Your one-page ethical-impact assessment goes in SUBMISSION.md, under 6.2.

Both scripts run entirely on your machine. Nothing is uploaded, and nothing
leaves your computer. The scripts only read this folder and write one zip
into it.

Full instructions, including what to do when it stops:
the Submit step at the end of the Week 3 lab on the course site.
