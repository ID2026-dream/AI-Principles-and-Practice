# Week 3 Lab Submission — Auditing a Model for Bias

AI Principles and Practice · COMP-0987 · Topic 03, Unit 02

One section below for each section of the lab. Answer as you go, rather than
at the end — most of these are the checkpoint questions you have already talked
through at the bench.

Short answers. One or two sentences unless it says otherwise. Delete each
`TODO` as you finish that section, then run `python make_submission.py`.

| | |
|---|---|
| Student number | TODO |
| Name | TODO |
| Date | TODO |

---

## Setup

**0.1 Paste the accuracy, AUC and base rate your setup script printed. Which
column did we deliberately leave out of the model, and what is that approach
called?**

TODO

---

## Section 1 — One model, two groups

**1.1 Paste your two per-group confusion-matrix lines. What are the two base
default rates, and which group is higher?**

TODO

**1.2 In `mf.by_group`, is the `flag_rate` higher for the group with the higher
base rate? Why would you expect that even from an unbiased model?**

TODO

**1.3 In this dataset the positive class is "default". What is the favourable
outcome, and why does mixing the two up wreck a fairness audit?**

TODO

---

## Section 2 — Group fairness, and a comfortable green light

**2.1 Your approval rates, demographic-parity gap and disparate-impact ratio.
Does the model pass the four-fifths rule at 0.5?**

TODO

**2.2 Paste your threshold sweep (0.5, 0.3, 0.2). What happens to the ratio,
and what does that tell you about what a disparate-impact ratio is a property
of?**

TODO

**2.3 Give one reason a passing four-fifths ratio is not sufficient evidence
that the model is fair.**

TODO

---

## Section 3 — Fairness on the errors, and the base-rate trap

**3.1 Your equalised-odds difference and per-group TPR and FPR. Which group has
the higher true-positive rate, and by how much? Say in plain words what that
TPR means here.**

TODO

**3.2 One sentence on your `cal_by_group.png`. Is the model calibrated within
each group?**

TODO

**3.3 If the model is calibrated for both groups but their base default rates
differ, what does that force to be unequal? Write your guess now; Section 5
tests it.**

TODO

---

## Section 4 — Did dropping the column actually work?

**4.1 Your probe accuracy, the majority-guess baseline, and the lift. Did
dropping `SEX` remove it from the model's inputs?**

TODO

**4.2 On a hiring dataset where postcode is a strong proxy for ethnicity, would
you expect the same answer? What would that imply about dropping the ethnicity
column?**

TODO

**4.3 Look back at your Week 2 answer to 6.2. Were you right, and what did you
not know then that you know now?**

TODO

---

## Section 5 — The impossibility, made real

**5.1 Paste your three-row table (as trained, enforce demographic parity,
enforce equalised odds). Which single number is the evidence that the two
criteria conflict?**

TODO

**5.2 Exercise 5.2: two sentences explaining why the trade is forced, using
your base rates.**

TODO

**5.3 If someone hands you a tool that promises a "fair" model with no further
questions, what has it silently done?**

TODO

---

## Section 6 — Mitigation, its cost, and the assessment

**6.1 Your before/after accuracy and per-group approval rates. Name the true
cost of the demographic-parity mitigation. It is not accuracy.**

TODO

**6.2 Your one-page ethical-impact assessment, in the five parts: Context,
Findings, Choice, Cost, Residual risk. Lead the Findings with the worst gap,
defend your criterion in the Choice, and say in Residual risk what would make
you refuse to deploy. This is the longest answer in the file; roughly a page.**

TODO

---

## Section 7 — Exercises

Attempt 7.1 and 7.2, then do *either* 7.3 *or* 7.4, and finish with 7.5.

**7.1 Your EDUCATION audit: approval rates, disparate-impact ratio and
equalised-odds difference. Did it pass the four-fifths rule, and was its
equalised-odds gap larger or smaller than for `SEX`?**

TODO

**7.2 How did the disparate-impact ratio and the equalised-odds gap change at
threshold 0.3? Which operating point would you actually audit for a lender,
and why?**

TODO

**7.3 or 7.4 — say which one you did, then answer it.**

TODO

**7.5 Your 200 words: this model passes the four-fifths rule; is it fair?**

TODO

---

## Before you build the zip

**Use of AI assistants.** Say what you used one for, if anything, and what you
checked yourself. Using one is allowed; not being able to explain your own
submission is the problem. "None" is a complete answer.

TODO

**Anything you want to flag.** Optional — if something went wrong, if you ran
out of time, or if you want a second opinion on a judgement call. Delete the
TODO either way.

TODO
