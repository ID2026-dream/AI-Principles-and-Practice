Week 4 lab files — AI Principles and Practice

UCI_Credit_Card.csv   Default of Credit Card Clients (Yeh & Lien, 2009),
                      UCI Machine Learning Repository,
                      https://doi.org/10.24432/C55S3H, CC BY 4.0.
                      30,000 clients of a Taiwanese bank, Apr-Sep 2005.
                      The same file as Weeks 1 to 3. This week the Week 2
                      default classifier, with SEX back in its inputs, is
                      explained with SHAP and LIME, stressed with a
                      simulated downturn, and documented.

Put it in your Week 4 lab folder, then unzip the Week 04 Submission Kit
beside it.

  pip install numpy pandas scikit-learn scipy matplotlib shap lime
