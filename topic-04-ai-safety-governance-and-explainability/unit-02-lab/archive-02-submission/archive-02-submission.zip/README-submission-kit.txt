Week 4 lab submission kit — AI Principles and Practice
======================================================

Unzip this into the same folder as your Week 4 lab work, so that it sits
alongside UCI_Credit_Card.csv from the Week 04 Lab Files archive.

  SUBMISSION.md        Your answers. Fill it in and delete each TODO.
  make_submission.py   Builds the single zip you upload. Run it last.
  setup_check.py       Environment report. Run it before the lab.
                       This week it also checks for shap and lime.

Three steps, the same every week:

  1. Answer SUBMISSION.md as you work through Sections 1 to 7
  2. python make_submission.py
  3. Upload the one zip it names to the OneDrive folder on the course site

Keep your code and plots in this folder as you write them
(section2_shap.py, section4_shift.py, exercise_7_3.py, a notebook —
whatever you used). They go into the zip automatically. The provided
UCI_Credit_Card.csv does not.

Your governance note goes in SUBMISSION.md under 5.3 (revised under 7.4).
Your model card goes under 6.2, and your datasheet answers under 6.3.

Both scripts run entirely on your machine. Nothing is uploaded, and nothing
leaves your computer. The scripts only read this folder and write one zip
into it.

Full instructions, including what to do when it stops:
the Submit step at the end of the Week 4 lab on the course site.
