# Week 4 Lab Submission — Safety, Governance and Explainability

AI Principles and Practice · COMP-0987 · Topic 04, Unit 02

One section below for each section of the lab. Answer as you go, rather than
at the end — most of these are the checkpoint questions you have already talked
through at the bench.

Short answers. One or two sentences unless it says otherwise. Delete each
`TODO` as you finish that section, then run `python make_submission.py`.

| | |
|---|---|
| Student number | TODO |
| Name | TODO |
| Date | TODO |

---

## Setup

**0.1 Paste the shape and default rate your setup script printed.**

TODO

---

## Section 1 — Safety, the gap between what you asked for and what you got

**1.1 Paste the accuracy, recall and AUC your rebuilt model printed. Which of
accuracy and recall would a careless summary quote, and why is that the
dangerous choice?**

TODO

**1.2 Exercise 1.2: name two things that get lost in the gap between "identify
people who cannot safely be given credit" and "predict the recorded default
label".**

TODO

**1.3 Your symptom-to-mechanism matches for the three rows of the table.**

TODO

**1.4 The difference between a bug and a safety failure, in one sentence each.**

TODO

---

## Section 2 — Explain it globally, importance and SHAP

**2.1 Paste your top five permutation importances. Why would a single "were you
late last month" feature dominate a default model, and what does that say about
how much independent information the other features carry?**

TODO

**2.2 Paste your top four features by mean |SHAP|. In two sentences, why is it
not a contradiction that permutation importance says `SEX` barely matters and
SHAP puts it third?**

TODO

**2.3 SHAP shows `SEX` is a top-three driver. Is that a bug in SHAP, a bug in
the model, or neither?**

TODO

---

## Section 3 — Explain it locally, LIME and where explanations mislead

**3.1 Paste the LIME explanation for your false negative. In one sentence, what
story does it tell about why the model approved this client?**

TODO

**3.2 Paste your seed 0 and seed 7 top-three lists. Name one other LIME setting
the seed test did not touch, and say why a stable result on a linear model would
not carry over to a tree ensemble.**

TODO

**3.3 Your `SEX`-recovery accuracy and its base rate. What would a *high*
recoverability number have implied about dropping the column?**

TODO

**3.4 One sentence: why is "we applied SHAP and LIME" not, by itself, a
fairness defence for this model?**

TODO

---

## Section 4 — Break it on purpose, robustness and silent failure

**4.1 Paste your before-and-after table. Why did the approval rate stay exactly
the same while the approved book got worse?**

TODO

**4.2 Why is accuracy a poor *live* monitor for a deployed credit model
specifically?**

TODO

**4.3 Exercise 4.2: two things you could watch in real time that would give
early warning of this downturn before the defaults roll in. Two or three
sentences.**

TODO

---

## Section 5 — Govern it, GDPR, the EU AI Act, and a governance note

**5.1 Exercise 5.1, one specific sentence for each: GDPR Article 22 (which
right, and what a "meaningful" human in the loop would have to look like); the
EU AI Act (the tier, and which two high-risk obligations today's lab already
produces evidence for); and the NIST AI RMF (which function your Section 4
monitoring plan belongs to).**

TODO

**5.2 Name one concrete place where GDPR data minimisation and the EU AI Act's
documentation demands pull against each other for this model, and how you
would satisfy both.**

TODO

**5.3 Your governance note, in the five lines: Tier and obligations;
Explanation, and its limit; Robustness; Monitoring; Refusal. Every line
specific to what you measured today. Up to a page.**

TODO

**5.4 Why is "solely" the load-bearing word in Article 22 for this model, and
what does "high-risk" flip about the burden of proof?**

TODO

---

## Section 6 — Document it, a model card and a datasheet

**6.1 Paste your disaggregation table (decline rate, recall and base default
rate by group). Why is a disaggregated metric worth more to a reader than a
single accuracy figure?**

TODO

**6.2 Your model card, in the five parts: Intended use; Out-of-scope use;
Metrics (disaggregated); Ethical considerations; Caveats. The last two are
where the marks are.**

TODO

**6.3 Your datasheet answers: who is in this dataset and who is missing; how
the `default` label was defined and by whom; and one use that would be
inappropriate.**

TODO

**6.4 "Ethical considerations: none identified." What does that line actually
confess?**

TODO

---

## Section 7 — Exercises

Work top to bottom, as the lab asks. 7.3 and 7.4 are the elective and the
governance requirement in miniature, so do not skip them.

**7.1 Your false positive: which features drove the refusal, whether `SEX_2`
appears, and whether the explanation would satisfy the person refused.**

TODO

**7.2 Where your two explanations of the same decision diverged (LIME settings,
or LIME against SHAP), which you would trust for this decision, and why.**

TODO

**7.3 Your shift: what you imposed, one metric that moved and one that stayed
deceptively still, whether the SHAP ranking changed, and when this model's
explanation should *not* be trusted.**

TODO

**7.4 Your revised governance note (half a page), then one line on what your
partner flagged when you swapped notes.**

TODO

**7.5 The claim you picked, and the honest counter-case against taking it at
face value.**

TODO

---

## Before you build the zip

**Use of AI assistants.** Say what you used one for, if anything, and what you
checked yourself. Using one is allowed; not being able to explain your own
submission is the problem. "None" is a complete answer.

TODO

**Anything you want to flag.** Optional — if something went wrong, if you ran
out of time, or if you want a second opinion on a judgement call. Delete the
`TODO` either way.

TODO
