Week 5 lab files — AI Principles and Practice

UCI_Credit_Card.csv   Default of Credit Card Clients (Yeh & Lien, 2009),
                      UCI Machine Learning Repository,
                      https://doi.org/10.24432/C55S3H, CC BY 4.0.
                      30,000 clients of a Taiwanese bank, Apr-Sep 2005.
                      The same file as Weeks 1 to 4. This week both the
                      default label and SEX are removed, the rest is
                      clustered and projected with PCA, and SEX is then
                      tested for whether it can be recovered.

Put it in your Week 5 lab folder, then unzip the Week 05 Submission Kit
beside it.

  pip install numpy pandas scikit-learn scipy matplotlib
