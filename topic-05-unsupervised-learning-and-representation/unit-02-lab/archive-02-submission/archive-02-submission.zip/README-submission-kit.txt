Week 5 lab submission kit — AI Principles and Practice
======================================================

Unzip this into the same folder as your Week 5 lab work, so that it sits
alongside UCI_Credit_Card.csv from the Week 05 Lab Files archive.

  SUBMISSION.md        Your answers. Fill it in and delete each TODO.
  make_submission.py   Builds the single zip you upload. Run it last.
  setup_check.py       Environment report. Run it before the lab.
                       This week it also checks for scipy, which draws
                       the dendrogram.

Three steps, the same every week:

  1. Answer SUBMISSION.md as you work through Sections 1 to 7
  2. python make_submission.py
  3. Upload the one zip it names to the OneDrive folder on the course site

Keep your code and plots in this folder as you write them
(section2_scan.py, section4_loadings.py, section6_probe.py,
exercise_7_3.py, a notebook — whatever you used). They go into the zip
automatically. The provided UCI_Credit_Card.csv does not.

Your defended choice of K goes in SUBMISSION.md under 2.3, your named
components under 4.2, and your recoverability interpretation under 6.4
and 7.4.

Both scripts run entirely on your machine. Nothing is uploaded, and nothing
leaves your computer. The scripts only read this folder and write one zip
into it.

Full instructions, including what to do when it stops:
the Submit step at the end of the Week 5 lab on the course site.
