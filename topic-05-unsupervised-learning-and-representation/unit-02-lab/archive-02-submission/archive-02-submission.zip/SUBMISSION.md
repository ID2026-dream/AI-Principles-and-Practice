# Week 5 Lab Submission — Unsupervised Learning and the Idea of a Representation

AI Principles and Practice · COMP-0987 · Topic 05, Unit 02

One section below for each section of the lab. Answer as you go, rather than
at the end — most of these are the checkpoint questions you have already talked
through at the bench.

Short answers. One or two sentences unless it says otherwise. Delete each
`TODO` as you finish that section, then run `python make_submission.py`.

| | |
|---|---|
| Student number | TODO |
| Name | TODO |
| Date | TODO |

---

## Setup

**0.1 Paste the shape and default rate your setup script printed.**

TODO

---

## Section 1 — Learning without labels, and the dataset with its answer removed

**1.1 Paste the shape of your representation `Xt`. It has 27 columns from
roughly 22 original features: where did the extra columns come from?**

TODO

**1.2 Name the two columns you removed, and why you removed each one.**

TODO

**1.3 Exercise 1.2: one thing you can no longer do now that `default` is gone,
and one thing you can now do that you could not in Weeks 2 to 4.**

TODO

**1.4 Exercise 1.2: your sentence, "A good clustering of these clients would be
one that ______." Write it before Section 5 and do not edit it afterwards.**

TODO

**1.5 Why is there no train/test split in this section, when every previous
week began with one?**

TODO

---

## Section 2 — K-means, and choosing K by argument

**2.1 Paste your K, inertia and silhouette lines for K = 2 to 8.**

TODO

**2.2 What is the honest reading of a *clear* silhouette preference for K = 2
at a *weak* absolute height of about 0.356?**

TODO

**2.3 Your one-sentence defence of the K you chose, written as you would put it
in a report.**

TODO

**2.4 Paste your cluster sizes and the small-cluster-versus-rest comparison.
Who is the small cluster, and what does the lopsided split tell you that the
silhouette number alone did not?**

TODO

**2.5 Why must `n_init` be above 1, and what goes wrong if the starting centres
are unlucky?**

TODO

---

## Section 3 — Hierarchical, Gaussian mixtures, and the limits of validity

**3.1 In hierarchical clustering, who chooses where to cut the tree, and what
exactly is the modelling decision that has your name on it?**

TODO

**3.2 Paste your two Gaussian-mixture shares (assigned with > 0.99 confidence,
and genuinely uncertain below 0.6). What do they say about how cleanly the
big-balance group separates from the rest?**

TODO

**3.3 Exercise 3.2: every one of these methods returns an answer on any data,
including data with no clusters at all. In two sentences, what does the
algorithm certify, and what must you establish yourself?**

TODO

**3.4 Exercise 3.3: why is a high silhouette not, by itself, evidence that a
clustering is useful? Then name one dataset shape where K-means would mislead
and a Gaussian mixture would not.**

TODO

---

## Section 4 — PCA, a representation you can watch being learned

**4.1 Paste the explained variance for PC1 to PC4, the two-component total, and
the number of components needed for 90%. Two components hold about half the
variance here, against 86% in the lecture's example: what does that difference
tell you about real versus tidy data?**

TODO

**4.2 Paste PC1's top six loadings. Name PC1 in plain domain language, then do
the same for PC2 from `pca.components_[1]`, citing the loadings that support
each name.**

TODO

**4.3 In one sentence: what does PCA learn from the data, and why does that make
it a representation rather than just compression?**

TODO

---

## Section 5 — The representation, and geometry as meaning

**5.1 Paste the default rate for each cluster and overall. Does the clustering
meet the definition of "good" you wrote under 1.4? Two sentences on what it
means that an unsupervised method found strong, real structure that is
irrelevant to the outcome you care about.**

TODO

**5.2 You used the `default` label in this section. Why is that not cheating at
unsupervised learning?**

TODO

**5.3 Exercise 5.2: what does "these two clients are similar" mean once
similarity is defined as distance in a representation somebody chose?**

TODO

**5.4 One sentence: why does the choice of representation shape everything
downstream of it?**

TODO

---

## Section 6 — Whose fingerprints, recovering the protected attribute

**6.1 What did the scatter recoloured by `SEX` show, and why is eyeballing it not
evidence on its own?**

TODO

**6.2 Paste the base rate, the probe accuracy from the full representation and
from the 2D PCA representation, and the cluster/`SEX` adjusted Rand index. Why
is the base rate, and not fifty per cent, the right thing to compare against?**

TODO

**6.3 The probe scores about 0.612 against a base rate of about 0.604. In one
sentence, what does that let you conclude, and what does it not?**

TODO

**6.4 The lecture found 0.71 and you found about 0.612. Your two sentences for a
colleague who says "we removed the protected attribute, so the model can't be
biased on it".**

TODO

---

## Section 7 — Exercises

Work top to bottom, as the lab asks. 7.3 and 7.4 are Elective 2 in miniature,
so do not skip them.

**7.1 `AGE`: the bands you used, the probe accuracy, and the `AGE`-band base
rate. Does the "barely recoverable" result hold for `AGE`, or does it flip?**

TODO

**7.2 `SEX` recovery with and without the six `BILL_AMT` features, and what that
tells you about treating "the representation" as fixed.**

TODO

**7.3 Your recovery curve across 2, 10 and all PCA components against the base
rate, and the result for the K = 2 cluster labels alone. Where, if anywhere,
does leakage appear? Name the plot file if you saved one.**

TODO

**7.4 Your honest interpretation of the recovery results from 7.1 to 7.3. Where
an attribute was recoverable, what that means downstream; where it was not, what
you checked and why "unrecoverable here" is not "safe everywhere". Half a
page.**

TODO

**7.5 One thing the silhouette certifies, two things it cannot see, and a
clustering that would score well that you would still refuse to act on.**

TODO

---

## Before you build the zip

**Use of AI assistants.** Say what you used one for, if anything, and what you
checked yourself. Using one is allowed; not being able to explain your own
submission is the problem. "None" is a complete answer.

TODO

**Anything you want to flag.** Optional — if something went wrong, if you ran
out of time, or if you want a second opinion on a judgement call. Delete the
`TODO` either way.

TODO
