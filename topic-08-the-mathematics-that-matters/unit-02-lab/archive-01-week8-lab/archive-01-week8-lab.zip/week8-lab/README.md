# Week 8 Lab: The Math Behind the Models

**AI Principles and Practice · SETU**

> **This lab is not graded.** Submitting your `SUBMISSION.md` is how you show you did the work; then
> compare with the Week 8 Reference Answers on Tutors.

Six exercises, following the lecture's three parts: *shape* (Exercises 1 to 3), *surprise* (4 and 5)
and *space* (6). In each one you **predict** before you run, **run** the cell, **look** at the printout
the question names, and **explain** what you see in your own words. In Exercises 2 and 4 you **build**
the maths yourself: PCA via SVD, and entropy, cross-entropy and KL.

| Exercise | Lecture | Slides | You build | Time |
|---|---|---|---|---|
| 1 · Some directions only get longer | Part 1 | 5 to 7 | | 15 min |
| 2 · Build PCA via SVD | Part 1 | 8 to 11 | `my_pca` | 25 min |
| 3 · Keep the big pieces | Part 1 | 12 to 16 | | 15 min |
| 4 · Build entropy, cross-entropy and KL | Part 2 | 17 to 25 | three functions | 25 min |
| 5 · A real model's loss is surprise | Part 2 | 26 to 29 | | 15 min |
| 6 · Space: where does real data live? | Part 3 | 31 to 37 | | 20 min |
| | Two last questions, then submit | | | 10 min |

About 2 h 05 min. **If any exercise takes more than 40 minutes, stop and post in the channel.**

## What you need

Python 3.10 or newer with the packages in `requirements.txt`. **No PyTorch.** Or Google Colab.

```bash
pip install -r requirements.txt
python setup_check.py                # optional: checks your environment
jupyter notebook week8_lab.ipynb
```

For Exercise 6, copy the CSV file of **your project dataset from Weeks 1 to 5** into this folder.

## The files

| file | what it is | do I need it? |
|---|---|---|
| `week8_lab.ipynb` | **The lab.** Open this. | **yes** |
| `SUBMISSION.md` | **The answer sheet, blank.** Fill it in as you go, add your name. | **yes** |
| `WHERE_TO_FIND.md` | For each question, which cell to run and which printout to read. | **yes** |
| `lecture_steps.py` | One helper per lecture idea, and the checks for the code you write. Never edit it. | no |
| `setup_check.py` | Environment report: run it if something will not install or import. | no |
| `UCI_Credit_Card.csv` | The Week 1 credit data, for Exercise 5. | no |

## Submitting

Upload `SUBMISSION.md`, named `week08-<student number>-SUBMISSION.md`, using the link on the Submit page in
Tutors. Just that file. Then compare with the Week 8 Reference Answers.

Your `my_pca` from Exercise 2 is also the PCA via SVD your capstone needs: copy it into
`src/scratch/pca_svd.py` in your project repository, as `pca`.
