# Week 8 Lab: Submission  ·  graded

**Name:**   **Student number:**   **My project dataset (Weeks 1 to 5):**

> **This sheet is blank on purpose.** Fill it in as you go. Each question is one of five kinds:
> **Predict** (write it *before* you run the cell, and do not change it afterwards), **Record** (the
> numbers from the printout named), **Explain** (two or three sentences in your own words), **Build**
> (paste the code that passed its check) and **Change** (predict, change one thing, say what happened).
>
> Replace every `TODO` with your answer. `make_submission.py` will not build your zip while a `TODO` is
> left (use `--force` only if you are submitting incomplete work on purpose).
>
> This lab is graded on four criteria: completeness (25%), correctness and reproducibility (30%),
> application to your own project data (20%) and reasoning (25%).

---

## Exercise 1 · Some directions only get longer  *(slides 5 to 7)*

**1a · Predict.** Which of (1, 0), (0, 1), (1, 1), (1, −1), (2, 1) keep their direction under A, and by how much are they stretched?

TODO

**1b · Record and explain.** From Printout A: the arrows that kept their direction and their stretch factors. Was 1a right?

TODO

**1c · Explain.** Why is NumPy's (0.707, 0.707) the same eigenvector as (1, 1)?

TODO

---

## Exercise 2 · Build PCA via SVD  *(slides 8 to 11)*

**2a · Build.** Your five lines in `my_pca`:

```python
TODO
```

**2b · Predict.** Share of the height-and-arm-span spread along the main direction: about 50%, about 75%, or over 90%?

TODO

**2c · Record and explain.** Printout B: direction 1, the two variances, and the share. Why does one direction carry almost everything, and what does direction 1 mean in plain words?

TODO

---

## Exercise 3 · Keep the big pieces  *(slides 12 to 16)*

**3a · Predict.** Pieces needed for an error below 5%: about 5, about 20, or about 100?

TODO

**3b · Record.** Table A: numbers stored and error for k = 1, 5, 20, 60. Was 3a right?

TODO

**3c · Explain.** Why do the last pieces matter so little? Connect this to LoRA in one sentence.

TODO

**3d · Change** *(optional).* The smallest k you would accept for this photo, and why.

TODO — or write "not attempted"

---

## Exercise 4 · Build entropy, cross-entropy and KL  *(slides 17 to 25)*

**4a · Build.** Your three lines:

```python
TODO
```

**4b · Predict.** KL for the 70/20/10 forecaster: closer to 0.01, 0.1 or 1 bit? And for 90/8/2?

TODO

**4c · Record and explain.** Printout B: entropy, cross-entropy and KL, and the four KL values. Why is the first KL zero, and why does it grow so fast at the end?

TODO

---

## Exercise 5 · A real model's loss is surprise  *(slides 26 to 29)*

**5a · Predict.** Will the model's average surprise be much lower than the "22% default" model's, or only a little?

TODO

**5b · Record and explain.** Table C: the four numbers. Why do "by hand" and `log_loss` agree?

TODO

**5c · Explain.** Connect the 0.08 bits per customer to what you saw in Week 2.

TODO

---

## Exercise 6 · Space: where does real data live?  *(slides 31 to 37)*

**6a · Predict.** Share of a 100-dimensional orange that is peel: below 50%, about 90%, or above 99%?

TODO

**6b · Record and explain.** Printouts A and B. Why would "find the nearest neighbour" stop working well in 1,000 dimensions?

TODO

**6c · Predict.** Directions needed to keep 90% of the spread: for the digits, and for random noise.

TODO

**6d · Record.** Tables C and D, and the name of your dataset (or "the credit data", if you had none).

TODO

**6e · Explain.** What does your number tell you about *your* data, and what would you expect if you trained a model on just those directions?

TODO

---

## Two last questions

**L1.** In one sentence each: what does the SVD find, what does KL measure, and what is an intrinsic dimension?

TODO

**L2.** Which prediction today was furthest off, and what do you think now?

TODO
