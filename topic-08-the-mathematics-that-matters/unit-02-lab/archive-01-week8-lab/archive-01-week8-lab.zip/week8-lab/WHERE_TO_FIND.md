# Week 8 Lab: which cell to run, and which printout to read, for each question

Predict questions are answered **before** the cell they point at. Build questions need their check cell
to show ✓ on every line.

| Exercise | Slides | Run | Read | Questions |
|---|---|---|---|---|
| 1 | 5 to 7 | `ls.stretch_arrows()`, `ls.eigen_check()` | Printouts A and B | 1a predict · 1b Printout A · 1c Printout B |
| 2 | 8 to 11 | your `my_pca` + `ls.check_my_pca`, `ls.height_span(my_pca)` | the check, Printout B | 2a build · 2b predict · 2c Printout B |
| 3 | 12 to 16 | `ls.shrink_photo()`, optional `ls.shrink_photo((2, 3, 10))` | Table A | 3a predict · 3b, 3c Table A · 3d optional |
| 4 | 17 to 25 | `ls.surprise_table()`, your three functions + `ls.check_my_information`, `ls.weather(...)` | Printouts A and B | 4a build · 4b predict · 4c Printout B |
| 5 | 26 to 29 | `ls.credit_surprise()` | Table C | 5a predict · 5b, 5c Table C |
| 6 | 31 to 37 | `ls.orange_peel()`, `ls.distances()`, `ls.digits_and_noise(my_pca)`, your project data cell | Printouts A and B, Tables C and D | 6a, 6c predict · 6b Printouts A, B · 6d, 6e Tables C, D |

Exercise 6's own-data questions (6d and 6e) are the ones about *your* dataset: they are the most useful practice
for your capstone.
