"""lecture_steps.py — Week 8: one helper per lecture idea, and the checks for the code you write.

You run these from the notebook; you never need to edit or open this file.
"""
import math
import os
import warnings

import numpy as np
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
os.makedirs("figures", exist_ok=True)


def _ok(msg):
    print(f"  ✓ {msg}")


def _no(msg):
    print(f"  ✗ {msg}")


def _needs(fn, ex):
    """Run a student function; if it is not finished yet, say so instead of crashing."""
    def wrapped(*a, **k):
        try:
            out = fn(*a, **k)
        except Exception:
            out = None
        if out is None or (isinstance(out, tuple) and any(o is None for o in out)):
            raise _NotYet(ex)
        return out
    return wrapped


class _NotYet(Exception):
    pass


def _friendly(ex):
    def deco(f):
        def g(*a, **k):
            try:
                return f(*a, **k)
            except _NotYet:
                print(f"  ✗ Finish Exercise {ex} first: its check must show ✓ on every line, then run this cell again.")
        g.__doc__ = f.__doc__
        return g
    return deco


# ============================================================ data
def picture(h=120, w=180):
    """The lecture's photo: a 120 × 180 table of brightness values between 0 and 1."""
    y, x = np.mgrid[0:h, 0:w]
    img = 0.85 - 0.45 * y / h
    img[((x - 135) ** 2 + (y - 30) ** 2) < 14 ** 2] = 1.0
    ridge = 70 + 18 * np.sin(x / 17.0) + 8 * np.sin(x / 5.3)
    img[y > ridge] = 0.32 + 0.1 * np.sin(x[y > ridge] / 9.0)
    lake = y > 100
    img[lake] = 0.55 + 0.08 * np.sin(y[lake] * 1.3) * np.cos(x[lake] / 7.0)
    for k in range(5):
        cx = 20 + k * 34
        img[(y > 62) & (y < 98) & (np.abs(x - cx) < (y - 62) / 3.2)] = 0.12
    rng = np.random.default_rng(3)
    noise = rng.normal(size=(h, w))
    fy, fx = np.meshgrid(np.fft.fftfreq(h), np.fft.fftfreq(w), indexing="ij")
    smooth = np.real(np.fft.ifft2(np.fft.fft2(noise) * np.exp(-(fx ** 2 + fy ** 2) / (2 * 0.05 ** 2))))
    img = img + 0.10 * smooth / np.abs(smooth).max() + 0.03 * rng.normal(size=(h, w))
    return np.clip(img, 0, 1)


def height_and_span():
    """300 people: height and arm span in centimetres (the lecture's cloud)."""
    rng = np.random.default_rng(8)
    height = rng.normal(172, 9, 300)
    return np.c_[height, height + rng.normal(0, 3.5, 300)]


def load_credit(path="UCI_Credit_Card.csv"):
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    df = pd.read_csv(path)
    y = df["default.payment.next.month"].to_numpy()
    X = df.drop(columns=["ID", "default.payment.next.month"]).to_numpy(float)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)
    sc = StandardScaler().fit(Xtr)
    return sc.transform(Xtr), ytr, sc.transform(Xte), yte


def load_project(path=None):
    """Your own project dataset from Weeks 1 to 5, as a table of numbers.

    path: your CSV file. Keeps the numeric columns, drops rows with missing values,
    and scales every column to mean 0 and spread 1. With no path, uses the credit data.
    """
    import pandas as pd
    from sklearn.preprocessing import StandardScaler
    if path is None:
        path, name = "UCI_Credit_Card.csv", "the credit data (no project file given)"
    else:
        name = os.path.basename(path)
    df = pd.read_csv(path).select_dtypes("number").dropna()
    df = df.loc[:, df.std() > 0]
    drop = [c for c in df.columns if c.lower() in ("id", "default.payment.next.month")]
    df = df.drop(columns=drop)
    print(f"Loaded {name}: {len(df)} rows, {df.shape[1]} numeric columns")
    return StandardScaler().fit_transform(df.to_numpy(float))


# ============================================================ Exercise 1 · shape
A = np.array([[3.0, 1.0], [1.0, 3.0]])


def stretch_arrows():
    """Part 1. Multiply five arrows by A = [[3, 1], [1, 3]]."""
    print("Printout A: A = [[3, 1], [1, 3]] times five arrows")
    for v in ([1, 0], [0, 1], [1, 1], [1, -1], [2, 1]):
        v = np.array(v, float)
        w = A @ v
        cos = w @ v / (np.linalg.norm(w) * np.linalg.norm(v))
        same = abs(abs(cos) - 1) < 1e-9
        tag = f"same direction, stretched ×{np.linalg.norm(w) / np.linalg.norm(v):.0f}" if same else "turned"
        print(f"  {tuple(int(t) for t in v)!s:9} →  {tuple(int(t) for t in w)!s:9}   {tag}")


def eigen_check():
    """Part 1. NumPy finds the special directions for you."""
    vals, vecs = np.linalg.eigh(A)
    print("Printout B: np.linalg.eigh(A)")
    for lam, v in sorted(zip(vals, vecs.T), key=lambda t: -t[0]):
        v = v if v[0] > 0 else -v
        Av = A @ v
        print(f"  eigenvalue {lam:.0f}   eigenvector ({v[0]:+.3f}, {v[1]:+.3f})   check: A·v = ({Av[0]:+.3f}, {Av[1]:+.3f}) = {lam:.0f} × v")


# ============================================================ Exercise 2 · PCA via SVD (build)
def check_my_pca(my_pca):
    """Exercise 2, Build. Does my_pca agree with scikit-learn?"""
    from sklearn.decomposition import PCA
    print("Check: my_pca")
    rng = np.random.default_rng(0)
    X = rng.normal(size=(200, 5)) @ rng.normal(size=(5, 5)) + 3.0
    try:
        out = my_pca(X, 3)
    except Exception as e:
        if "NoneType" in str(e) or "cannot unpack" in str(e):
            _no("a line still says None. Fill in the five steps, starting with step 1.")
        else:
            _no(f"calling it raised {type(e).__name__}: {e}")
        return
    if out is None or any(o is None for o in out):
        _no("it returns None somewhere. Fill in the five steps.")
        return
    comps, var, scores = (np.asarray(o, float) for o in out)
    if comps.shape != (3, 5) or var.shape != (3,) or scores.shape != (200, 3):
        _no(f"shapes should be (3, 5), (3,) and (200, 3); yours are {comps.shape}, {var.shape} and {scores.shape}.")
        return
    _ok("shapes: 3 directions of 5 numbers, 3 variances, 200 × 3 scores")
    if not np.allclose(scores.mean(0), 0, atol=1e-8):
        _no("the scores do not average to zero: did you centre the data (step 1)?")
        return
    ref = PCA(n_components=3).fit(X)
    if not np.allclose(var, ref.explained_variance_, rtol=1e-6):
        hint = " Divide by n − 1, not n." if np.allclose(var, ref.explained_variance_ * (len(X) - 1) / len(X), rtol=1e-6) else ""
        _no("the variances do not match scikit-learn's." + hint + " Step 4 is S[:k] ** 2 / (n - 1).")
        return
    _ok("variances match scikit-learn")
    for k in range(3):
        s = np.sign(comps[k] @ ref.components_[k])
        if not np.allclose(s * comps[k], ref.components_[k], atol=1e-6):
            _no("the directions do not match. Step 3 is the first k rows of Vt.")
            return
    _ok("directions match scikit-learn (a direction may point either way)")
    print("  All correct: this function is the one your capstone uses in src/scratch/pca_svd.py.")


@_friendly(2)
def height_span(my_pca):
    """Part 1. Which way does the height-and-arm-span cloud stretch?"""
    my_pca = _needs(my_pca, 2)
    X = height_and_span()
    comps, var, _ = my_pca(X, 2)
    c = comps[0] if comps[0][0] > 0 else -comps[0]
    print("Printout B: 300 people, height and arm span (cm)")
    print(f"  direction 1: ({c[0]:.2f}, {c[1]:.2f})   variance {var[0]:.1f}")
    print(f"  direction 2: variance {var[1]:.1f}")
    print(f"  direction 1 carries {var[0] / var.sum():.0%} of the spread")


# ============================================================ Exercise 3 · low rank
def shrink_photo(ks=(1, 5, 20, 60)):
    """Part 1. Keep the k biggest SVD pieces of the photo."""
    P = picture()
    U, S, Vt = np.linalg.svd(P, full_matrices=False)
    m, n = P.shape
    print(f"Table A: the {m} × {n} photo, keeping k pieces")
    print(f"  {'k':>4}   {'numbers stored':>15}   {'error':>6}")
    fig, axes = plt.subplots(1, len(ks), figsize=(3.2 * len(ks), 2.6))
    for ax, k in zip(np.atleast_1d(axes), ks):
        R = (U[:, :k] * S[:k]) @ Vt[:k]
        err = np.linalg.norm(P - R) / np.linalg.norm(P)
        print(f"  {k:>4}   {k * (m + n + 1) / (m * n):>15.0%}   {err:>6.1%}")
        ax.imshow(np.clip(R, 0, 1), cmap="gray", vmin=0, vmax=1)
        ax.set_title(f"k = {k}"); ax.set_xticks([]); ax.set_yticks([])
    plt.tight_layout(); plt.savefig("figures/01_photo.png", dpi=110); plt.show()


# ============================================================ Exercise 4 · surprise (build)
def surprise_table():
    print("Printout A: surprise = −log₂ p")
    for p, what in ((0.5, "a coin lands heads"), (1 / 6, "a die shows six"), (1 / 64, "a 1-in-64 event"), (0.95, "a 95% forecast comes true")):
        print(f"  {what:<26} p = {p:.3f}   surprise = {-math.log2(p):.2f} bits")


def check_my_information(my_entropy, my_cross_entropy, my_kl):
    """Exercise 4, Build. Entropy, cross-entropy and KL, in bits."""
    print("Check: my_entropy, my_cross_entropy, my_kl")
    p, q = np.array([0.5, 0.3, 0.2]), np.array([0.7, 0.2, 0.1])
    H = float(-(p * np.log2(p)).sum())
    CE = float(-(p * np.log2(q)).sum())
    tests = [("my_entropy([0.5, 0.5])", lambda: my_entropy(np.array([0.5, 0.5])), 1.0),
             ("my_entropy(weather)", lambda: my_entropy(p), H),
             ("my_cross_entropy(weather, forecast)", lambda: my_cross_entropy(p, q), CE),
             ("my_kl(weather, forecast)", lambda: my_kl(p, q), CE - H),
             ("my_kl(weather, weather)", lambda: my_kl(p, p), 0.0)]
    for name, f, want in tests:
        try:
            got = f()
        except Exception as e:
            _no(f"{name} raised {type(e).__name__}: {e}")
            return
        if got is None:
            _no(f"{name} returns None. Replace `return None` with your line.")
            return
        if abs(float(got) - want) > 1e-9:
            hint = " Use np.log2, not np.log." if abs(float(got) - want * math.log(2)) < 1e-9 else ""
            _no(f"{name} should be {want:.3f}, yours is {float(got):.3f}.{hint}")
            return
        _ok(f"{name} = {want:.3f}")
    print("  All correct.")


@_friendly(4)
def weather(my_entropy, my_cross_entropy, my_kl):
    my_entropy, my_cross_entropy, my_kl = (_needs(f, 4) for f in (my_entropy, my_cross_entropy, my_kl))
    p, q = np.array([0.5, 0.3, 0.2]), np.array([0.7, 0.2, 0.1])
    print("Printout B: real odds 50/30/20 (sunny/cloudy/rain); forecaster believes 70/20/10")
    print(f"  entropy of the real odds:  {my_entropy(p):.3f} bits")
    print(f"  cross-entropy:             {my_cross_entropy(p, q):.3f} bits")
    print(f"  KL (the extra surprise):   {my_kl(p, q):.3f} bits")
    print("  For four forecasters, from right to very wrong:")
    for qq in ([0.5, 0.3, 0.2], [0.6, 0.25, 0.15], [0.7, 0.2, 0.1], [0.9, 0.08, 0.02]):
        print(f"    believes {'/'.join(str(int(round(v * 100))) for v in qq):<9} KL = {my_kl(p, np.array(qq)):.3f} bits")


# ============================================================ Exercise 5 · a real model's loss
def credit_surprise():
    """Part 2. The loss of a real model, read as surprise."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import log_loss
    Xtr, ytr, Xte, yte = load_credit()
    m = LogisticRegression(max_iter=1000).fit(Xtr, ytr)
    q = m.predict_proba(Xte)[:, 1]
    q_true = np.where(yte == 1, q, 1 - q)                # the odds the model gave the right answer
    by_hand = float(np.mean(-np.log(q_true)))
    base = ytr.mean()
    q0 = np.where(yte == 1, base, 1 - base)
    know_nothing = float(np.mean(-np.log(q0)))
    print("Table C: logistic regression on the credit data (7,500 test customers)")
    print(f"  average surprise at the right answer, by hand:   {by_hand:.4f} nats")
    print(f"  scikit-learn's log_loss:                          {log_loss(yte, q):.4f} nats")
    print(f"  a model that only knows 22% default:              {know_nothing:.4f} nats   ({know_nothing / math.log(2):.3f} bits)")
    print(f"  what the 23 features tell the model:              {know_nothing - by_hand:.4f} nats   ({(know_nothing - by_hand) / math.log(2):.3f} bits per customer)")


# ============================================================ Exercise 6 · space
def orange_peel():
    print("Printout A: share of an orange that is peel (the outer 10%)")
    for d in (2, 3, 10, 100):
        print(f"  {d:>3} dimensions: {1 - 0.9 ** d:.3%}")


def distances():
    rng = np.random.default_rng(1)
    print("Printout B: 400 random points; farthest pair ÷ nearest pair")
    for d in (2, 10, 100, 1000):
        X = rng.random((400, d))
        sq = (X ** 2).sum(1)
        D = np.sqrt(np.maximum(sq[:, None] + sq[None, :] - 2 * X @ X.T, 0))[np.triu_indices(400, 1)]
        print(f"  {d:>5} dimensions: {D.max() / D.min():8.2f} ×")


@_friendly(2)
def count_directions(my_pca, X, name="this data", target=0.90):
    """How many directions keep 90% of the spread (a rough intrinsic dimension)."""
    my_pca = _needs(my_pca, 2)
    k_all = min(X.shape)
    _, var, _ = my_pca(X, k_all)
    share = np.cumsum(var) / np.sum(var)
    k = int(np.searchsorted(share, target) + 1)
    print(f"  {name}: {k} of {X.shape[1]} directions keep {target:.0%} of the spread")
    return k


@_friendly(2)
def digits_and_noise(my_pca):
    my_pca = _needs(my_pca, 2)
    from sklearn.datasets import load_digits
    X = load_digits().data
    noise = np.random.default_rng(2).normal(size=X.shape)
    print("Table C: how many directions matter?")
    count_directions(my_pca, X, "handwritten digits (8 × 8 pixels)")
    count_directions(my_pca, noise, "random noise of the same size")
