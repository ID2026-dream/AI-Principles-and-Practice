# Week 10 Lab · Inside the Transformer

You take two finished, pretrained transformers (DistilBERT and GPT-2), freeze them, and open them up: read an
attention head, watch in-context learning happen with the weights fixed, probe the hidden layers against an honest
baseline, and measure what attention costs.

## Before the lab (once, at home)

```bash
uv venv --python 3.12 .venv && source .venv/bin/activate && uv pip install -r requirements.txt
# or: python3.12 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
python precache_models.py        # downloads about 750 MB of model weights, once
```

Use **Python 3.12**: PyTorch does not always publish wheels for the newest Python straight away.

## In the lab

```bash
jupyter notebook week10_lab.ipynb
```

Work top to bottom, and fill in `SUBMISSION.md` as you go. `WHERE_TO_FIND.md` says which cell answers which question.

## The files

| File | What it is | Do I open it? |
|---|---|---|
| `week10_lab.ipynb` | **The lab.** | **yes** |
| `SUBMISSION.md` | **The answer sheet, blank.** You hand this in. | **yes** |
| `WHERE_TO_FIND.md` | Which cell answers which question. | **yes** |
| `train.csv`, `test.csv` | AG News: 120,000 training and 7,600 test headlines, four topics | no |
| `precache_models.py` | Downloads the two models before the lab. | run once |
| `get_data.py` | Downloads `train.csv` and `test.csv` again if they are missing. | only if needed |
| `requirements.txt` | The packages. | no |

## The data

AG News: Zhang, X., Zhao, J. and LeCun, Y. (2015), *Character-level Convolutional Networks for Text Classification*,
NIPS 28, arXiv:1509.01626. The four largest classes (World, Sports, Business, Sci/Tech), 30,000 training and 1,900
test items each. The corpus is provided for non-commercial research purposes: treat it as teaching and research only.
Each file has three columns and no header row: the class (1 to 4), the title and the description.
