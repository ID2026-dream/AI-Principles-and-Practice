# Week 10 Lab · Inside the Transformer · Answer Sheet

**Name:**
**Student number:**

Fill this in as you go. Where a question asks you to **record**, copy the number or table from your own run: your
model-dependent numbers will differ from anyone else's, and that is expected. **Your number is the finding.**

How this lab is marked: the plots are the easy part. The marks are in the interpretation: naming what a head does and
showing where the claim holds and breaks, reading the in-context curve as evidence, saying exactly what a probe does
and does not show, and stating the limit of your own evidence (lecture slide 43).

---

## Section 1 · Attention from a real model

**1a.** The attention tensor is `(1, 12, seq, seq)` at each of six layers. In one phrase each, what are the `12` and
the two `seq` dimensions?

>

**1b.** Layer 3, head 4: describe in one sentence what this head seems to do. Then name one other head (layer and
head) that behaves visibly differently, and say how.

>

**1c.** Stress test (cell 1.3). State your claim about one head in one sentence. Which input should **hold** the
pattern, and did it? Which input should **break** it, and did it?

- Head (layer, head):
- Claim:
- Input that should hold, and what happened:
- Input that should break, and what happened:

**1d.** *Checkpoint 1.* What do the query, the key and the value each contribute, in one phrase each?

>

**1e.** *Checkpoint 1.* Why must every row of an attention matrix sum to one, and what does that force to be true?

>

---

## Section 2 · In-context learning, with the weights frozen

**2a.** No example was given, yet the model produced a category. If not from this prompt, where could any ability to
do the task at all have come from?

>

**2b.** Record your curve, then answer in two sentences: what changed between the runs to move the accuracy (the
weights did not), and why is it still fair to call this "learning"?

| Shots | Accuracy (chance = 0.25) |
|---|---|
| 0 | |
| 2 | |
| 4 | |

>

**2c.** Record the spread (cell 2.3). How big is the spread compared with the lift from 0 to 4 shots? What does that
mean for a curve made from one draw?

| Shots | Mean | Standard deviation |
|---|---|---|
| 2 | | |
| 4 | | |

>

**2d.** *Checkpoint 2.* What is held completely fixed during in-context learning, and what does that rule out as an
explanation?

>

**2e.** *Checkpoint 2.* Your lift was modest. Give the lecture-consistent reason, in terms of model size.

>

---

## Section 3 · Inside the transformer, probed against a baseline

**3a.** Record the bag-of-words (TF-IDF) accuracy.

> Bag-of-words accuracy:

**3b.** Record your probe accuracies. Then, in two sentences: what does the curve show, and how does your best layer
compare with the bag-of-words baseline? Be precise about what a successful probe does **not** prove.

| Layer | Probe accuracy |
|---|---|
| 0 (embedding, before any attention) | |
| 3 | |
| 6 | |

>

**3c.** *Checkpoint 3.* Why is layer 0 a useful baseline, and why keep the probe a plain linear model?

>

**3d.** *Checkpoint 3.* State the precise claim a successful probe licenses, and one claim it does not.

>

---

## Section 4 · The bill, and a caveat

**4a.** What would you have to give up to make attention cheaper than quadratic?

>

**4b.** One sentence you would say to a manager who points at a pretty attention picture and calls it the model's
reasoning.

>

**4c.** *Checkpoint 4.* Doubling the sequence length multiplied attention memory by how much, and why that factor?

>

**4d.** *Checkpoint 4.* Name one failure mode that a single accuracy number on a fixed test set would hide.

>

---

## Section 5 · Your capstone

**5a.** *(Lecture slide 30.)* Two sentences about **your** capstone data: (1) the structure it genuinely has (local
like an image, sequential like a log, relational like a graph, or none of these); (2) whether your chosen model
respects that structure or ignores it, and what that will cost you.

> Elective:
>
> 1.
>
> 2.

**5b.** Which of the Section 5 exercises (5.1 a head, 5.2 a probe, 5.3 in-context learning) will you do on your own
data, and why that one? If none fits your elective, say why a transformer is not the right tool for your data.

>

---

## 6 · The limit of your evidence

**6.** One claim your evidence from today **cannot** support, and why.

>
