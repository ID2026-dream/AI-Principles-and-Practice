# Where to Find Each Answer

| Question | Run this cell in `week10_lab.ipynb` | Then look at |
|---|---|---|
| 1a | 1.1 `section1_distilbert.py` | the printed shape `(1, 12, seq, seq)` and the tokens |
| 1b | 1.2 `section1_plot_head.py` (then change `layer`, `head` and rerun) | the heatmap, and the row sums |
| 1c | 1.3 `stress_test.py` (edit `layer`, `head` and the two sentences first) | the three heatmaps side by side |
| 1d, 1e | none | lecture slides 7 and 8; booklet Section 2 |
| 2a | 2.1 `section2_icl_setup.py` | the zero-shot prediction |
| 2b | 2.2 `section2_icl_curve.py` | the three accuracies |
| 2c | 2.3 `icl_spread.py` | the mean, standard deviation and the three runs per shot count |
| 2d, 2e | none | lecture slides 4 and 17 to 20; booklet Section 8 |
| 3a | 3.1 `section3_baseline.py` | `bag-of-words accuracy` |
| 3b | 3.2 `section3_probe_layers.py` | the probe accuracy for layers 0, 3 and 6 |
| 3c, 3d | none | lecture slides 41 and 43; booklet Section 16.4 |
| 4a | 4.1 `section4_quadratic.py` | the memory column, and the `x4.0` |
| 4b | none | lecture slides 35 and 36; booklet Sections 14 and 15 |
| 4c, 4d | 4.1 | the memory column; lecture slides 33 and 35 |
| 5a, 5b | none | lecture slides 30 and 44; your elective brief |
| 6 | none | everything above; booklet Section 16.6 |
