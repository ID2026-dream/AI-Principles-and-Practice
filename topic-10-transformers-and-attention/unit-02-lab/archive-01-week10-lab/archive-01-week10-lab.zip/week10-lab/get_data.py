"""Download AG News (train.csv, test.csv) into this folder, only if they are missing.

    python get_data.py

The lab normally ships with both files. Use this if yours are missing or damaged.
Source: the original AG News CSVs (Zhang, Zhao and LeCun, 2015, arXiv:1509.01626), from a public GitHub mirror.
The corpus is provided for non-commercial research purposes: treat it as teaching and research only.
"""
import hashlib
import sys
import urllib.request
from pathlib import Path

BASE = "https://raw.githubusercontent.com/mhjabreel/CharCnn_Keras/master/data/ag_news_csv/"
FILES = {
    "train.csv": "76a0a2d2f92b286371fe4d4044640910a04a803fdd2538e0f3f29a5c6f6b672e",
    "test.csv": "521465c2428ed7f02f8d6db6ffdd4b5447c1c701962353eb2c40d548c3c85699",
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


for name, digest in FILES.items():
    p = Path(name)
    if p.exists() and sha256(p) == digest:
        print(f"{name}: already here and correct")
        continue
    print(f"{name}: downloading ...")
    urllib.request.urlretrieve(BASE + name, p)
    if sha256(p) != digest:
        sys.exit(f"{name}: downloaded, but the checksum does not match. Delete it and try again, or ask in the channel.")
    print(f"{name}: done")
print("Data ready: 120,000 training and 7,600 test headlines.")
