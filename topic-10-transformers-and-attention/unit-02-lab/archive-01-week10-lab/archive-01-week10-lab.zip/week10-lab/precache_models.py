"""Download the two pretrained models once, before the lab (about 750 MB).

    python precache_models.py

Run this at home or on the lab machine BEFORE the session. On a shared network the download alone can take a
quarter of the lab. Once cached, the whole lab runs in three or four minutes of compute.
"""
from transformers import AutoModel, AutoModelForCausalLM, AutoTokenizer

for name, loader in (("distilbert-base-uncased", AutoModel), ("gpt2", AutoModelForCausalLM)):
    print(f"{name}: downloading (or checking the cache) ...")
    AutoTokenizer.from_pretrained(name)
    loader.from_pretrained(name)
    print(f"{name}: ready")
print("Both models are cached. You are ready for the lab.")
