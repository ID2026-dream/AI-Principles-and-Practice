# Week 11 Lab: Generating with Physics

**AI Principles and Practice · SETU**

2,000 points on a spiral. You will dissolve them into noise, teach a small network to undo the noise, and generate
brand-new points from pure noise. You will treat network layers as small steps of motion and learn a rule of motion.
Then, as in electives E5 and E6, you will teach a network with **zero data**, using only the equation the system obeys,
and find an unknown number with a simulator. Along the way you build in a symmetry, and break each idea on purpose.

Eight exercises, following the lecture. In each one you **predict** before you run, **run** the cell, **look** at the
printout the question names, and **explain** in your own words. In six of them you **build** one line yourself, and in
Exercises 5, 6 and 7 you **change one thing** to see a borrowed idea go quietly wrong.

| Exercise | Lecture | Slides | You build | Time |
|---|---|---|---|---|
| 1 · Add noise, step by step | Part 1 | 8 to 12, 17 | `my_noisy` | 15 min |
| 2 · Learn to undo it | Part 1 | 13 to 17 | `my_loss` | 20 min |
| 3 · Generate from pure noise | Part 1 | 18 to 22 | | 20 min |
| 4 · Roll downhill, with a little shaking | Part 4 | 50 to 52 | `my_langevin_step` | 15 min |
| 5 · Layers as steps; learn the rule (and a wrong rule) | Parts 2 and 5 | 24 to 32, 60 | `my_euler_step` | 20 min |
| 6 · Build the symmetry in (and a false one) | Parts 4 and 5 | 53 to 58, 63 | `my_radius` | 20 min |
| 7 · Zero data: let the equation teach (PINN and PIML) | Part 3 | 34 to 48, 62 | `my_leftover` | 25 min |
| 8 · Choosing | Part 5 | 64 to 66 | | 10 min |
| | Two last questions, then submit | | | 10 min |

About 2 h 35 min. **If any exercise takes more than 40 minutes, stop and post in the channel.**

## What you need

Python 3.10 or newer with the packages in `requirements.txt`. **No PyTorch**: everything runs in NumPy, and the
longest cell (training the denoiser) takes about 10 seconds. Or Google Colab.

```bash
pip install -r requirements.txt
jupyter notebook week11_lab.ipynb
```

## The files

| file | what it is | do I need it? |
|---|---|---|
| `week11_lab.ipynb` | **The lab.** Open this. | **yes** |
| `SUBMISSION.md` | **The answer sheet, blank.** Fill it in as you go, add your name. | **yes** |
| `WHERE_TO_FIND.md` | For each question, which cell to run and which printout to read. | **yes** |
| `lecture_steps.py` | The spiral, the denoiser, one helper per lecture idea, and the checks. Never edit it. | no |

## Submitting

Upload `SUBMISSION.md`, named `week11-<student number>-SUBMISSION.md`, using the link on the Submit page. Labs are not
graded this week. Then compare with the Week 11 Reference Answers.
