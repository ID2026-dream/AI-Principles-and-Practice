# Week 11 Lab: Submission

**Name:**   **Student number:**

> **This sheet is blank on purpose.** Fill it in as you go. Each question is one of five kinds:
> **Predict** (write it *before* you run the cell, and do not change it afterwards), **Record** (the numbers from
> the printout named), **Explain** (two or three sentences in your own words), **Build** (paste the code that
> passed its check) and **Change** (predict, change one thing, say what happened).

---

## Exercise 1 · Add noise, step by step  *(slides 8 to 12, 17)*

**1a · Build.** Your line in `my_noisy`:

```python

```

**1b · Predict.** At which step does the spiral stop being recognisable: around 5, 15, 30 or 49?

**1c · Record and explain.** Printout A. Was 1b right? Why does the distance to the spiral stop growing near the end?

---

## Exercise 2 · Learn to undo it  *(slides 13 to 17)*

**2a · Build.** Your line in `my_loss`:

```python

```

**2b · Predict.** After training, will the miss be near 0, about 0.3, or still about 1.0?

**2c · Record and explain.** Printout B. Why can the miss never reach 0?

---

## Exercise 3 · Generate from pure noise  *(slides 18 to 22)*

**3a · Predict.** Where will your generated points land: near 0.42 from the spiral (like noise), near 0.03 (like real points), or in between?

**3b · Record and explain.** Tables C and D. On the spiral? New points or copies?

**3c · Explain.** Why does it matter whether a generative model makes new points or copies of its training data?

---

## Exercise 4 · Roll downhill, with a little shaking  *(slides 50 to 52)*

**4a · Build.** Your line in `my_langevin_step`:

```python

```

**4b · Predict.** After 500 steps, roughly what share of the points will be in each valley?

**4c · Record and explain.** Printout E. What would happen with no shaking? With far too much?

---

## Exercise 5 · Layers as steps; learn the rule of motion  *(slides 24 to 32, 60)*

**5a · Build.** Your line in `my_euler_step`:

```python

```

**5b · Predict.** 20 big steps or 500 small ones: which ends closer, and by roughly how much?

**5c · Predict.** Learned rule or fitted curve: which predicts the next 10 seconds better?

**5d · Record and explain.** Printout F and Table G. Why does the rule predict so much better? Connect this to E5 and E6.

**5e · Change one thing.** Predict first: told "no friction", better or worse beyond 5 s, and by how much? Then record Printout G2 and explain why a wrong rule is dangerous even though its predictions look smooth and confident.

---

## Exercise 6 · Build the symmetry in  *(slides 53 to 58, 63)*

**6a · Build.** Your line in `my_radius`:

```python

```

**6b · Predict.** On the three unseen quarters: will the raw network still do well? And the distance model?

**6c · Record and explain.** Table H. Why does the raw network fail, and why can the distance model not fail?

**6d · Change one thing.** Predict first: top half or bottom half, how will the distance model do with 100, 1,000 and 10,000 points? Then record Table H2 and explain why more data cannot help it.

---

## Exercise 7 · Zero data: let the equation teach  *(slides 34 to 48, 62)*

**7a · Build.** Your line in `my_leftover`:

```python

```

**7b · Predict.** Zero measurements taught by the rule, or 40 real measurements from the first 4 s: which predicts better after 4 s?

**7c · Record and explain.** Printout J. How can a network with zero data beat one with 40 measurements beyond them?

**7d · Change one thing.** Predict first, then record and explain: (i) only 10 checkpoints; (ii) the start not built in.

**7e · Physics-informed ML.** Predict how close 20 noisy readings get to the true friction (0.3). Record Printout K. What does this mean for elective E5?

---

## Exercise 8 · Choosing  *(slides 64 to 66)*

**8a · Match first.** Before revealing Table I: (a) → [ ], (b) → [ ], (c) → [ ], (d) → [ ], (e) → [ ], (f) → [ ], (g) → [ ]

**8b · Compare.** Where did your match differ from Table I? One reason, in your own words, for each difference.

---

## Two last questions

**L1.** In one sentence each: what does a diffusion model learn, what is a neural ODE, and why build a symmetry into a model?

**L2.** Which prediction today was furthest off, and what do you think now?
