# Week 11 Lab: which cell to run, and which printout to read, for each question

Predict questions are answered **before** the cell they point at. Build questions need their check cell to show ✓
on every line.

| Exercise | Slides | Run | Read | Questions |
|---|---|---|---|---|
| 1 | 8 to 12, 17 | your `my_noisy` + `ls.check_my_noisy`, `ls.forward_steps(my_noisy)` | the check, Printout A | 1a build · 1b predict · 1c Printout A |
| 2 | 13 to 17 | your `my_loss` + `ls.check_my_loss`, `ls.train_denoiser(my_loss)` | the check, Printout B | 2a build · 2b predict · 2c Printout B |
| 3 | 18 to 22 | `ls.generate()`, `ls.inspect_samples()` | Tables C and D | 3a predict · 3b Tables C, D · 3c |
| 4 | 50 to 52 | your `my_langevin_step` + `ls.check_my_langevin`, `ls.langevin(...)` | the check, Printout E | 4a build · 4b predict · 4c Printout E |
| 5 | 24 to 32, 60 | your `my_euler_step` + `ls.check_my_euler`, `ls.layers_as_steps(...)`, `ls.learn_rule()`, `ls.wrong_rule()` | Printouts F and G2, Table G | 5a build · 5b, 5c predict · 5d Printout F, Table G · 5e change one thing, Printout G2 |
| 6 | 53 to 58, 63 | your `my_radius` + `ls.check_my_radius`, `ls.symmetry(my_radius)`, `ls.false_symmetry(my_radius)` | the check, Tables H and H2 | 6a build · 6b predict · 6c Table H · 6d change one thing, Table H2 |
| 7 | 34 to 48, 62 | your `my_leftover` + `ls.check_my_leftover`, `ls.zero_data(...)` three times, `ls.find_friction()` | the check, Printouts J and K | 7a build · 7b predict · 7c Printout J · 7d change one thing · 7e Printout K |
| 8 | 64 to 66 | `ls.show_choices()`, then (after matching) `ls.reveal_choices()` | Table I | 8a match first · 8b Table I |
