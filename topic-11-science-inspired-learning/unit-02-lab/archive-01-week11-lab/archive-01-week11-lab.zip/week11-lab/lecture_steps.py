"""lecture_steps.py — Week 11: one helper per lecture idea, and the checks for the code you write.

Everything runs in NumPy (and scikit-learn for one comparison). You never need to edit or open this file.
"""
import os
import time
import warnings

import numpy as np
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
os.makedirs("figures", exist_ok=True)


def _ok(m):
    print(f"  ✓ {m}")


def _no(m):
    print(f"  ✗ {m}")


def _finish(ex):
    print(f"  ✗ Finish Exercise {ex} first: its check must show ✓ on every line, then run this cell again.")


# ============================================================ the data: a spiral of 2,000 points
def spiral(n=2000, seed=0):
    rng = np.random.default_rng(seed)
    t = np.sqrt(rng.random(n)) * 3 * np.pi
    X = np.c_[t * np.cos(t), t * np.sin(t)] / 5.0
    return X + rng.normal(0, 0.04, X.shape)


DATA = spiral()
_tt = np.linspace(0, 3 * np.pi, 4000)
CURVE = np.c_[_tt * np.cos(_tt), _tt * np.sin(_tt)] / 5.0

# the noise schedule: 50 steps
T = 50
BETAS = np.linspace(1e-3, 0.2, T)
ALPHAS = 1 - BETAS
ABAR = np.cumprod(ALPHAS)


def distance_to_spiral(P):
    P = np.asarray(P)
    out = np.empty(len(P))
    for s in range(0, len(P), 500):
        out[s:s + 500] = np.sqrt(((P[s:s + 500, None, :] - CURVE[None]) ** 2).sum(-1)).min(1)
    return out


# ============================================================ Exercise 1 · add noise, step by step
def check_my_noisy(my_noisy):
    print("Check: my_noisy")
    x0, eps = np.array([[1.0, 2.0]]), np.array([[0.5, -1.0]])
    tests = [(0.81, np.sqrt(0.81) * x0 + np.sqrt(0.19) * eps), (1.0, x0), (0.0, eps)]
    for abar_t, want in tests:
        try:
            got = my_noisy(x0, eps, abar_t)
        except Exception as e:
            _no(f"my_noisy raised {type(e).__name__}: {e}")
            return
        if got is None:
            _no("my_noisy returns None. Replace None with your line.")
            return
        if not np.allclose(got, want):
            _no(f"with abar = {abar_t} the answer should be {np.round(want, 3).tolist()}; yours is {np.round(np.asarray(got), 3).tolist()}. Use square roots.")
            return
        _ok(f"abar = {abar_t}: {np.round(want, 3).tolist()[0]}")
    print("  All correct: abar = 1 keeps the data, abar = 0 is pure noise.")


def forward_steps(my_noisy, steps=(0, 5, 15, 30, 49)):
    try:
        assert my_noisy(np.zeros((1, 2)), np.zeros((1, 2)), 0.5) is not None
    except Exception:
        _finish(1)
        return
    rng = np.random.default_rng(1)
    eps = rng.normal(size=DATA.shape)
    print("Printout A: the spiral, noised (how much of the original is left, and how far points sit from the spiral)")
    fig, axes = plt.subplots(1, len(steps), figsize=(3.2 * len(steps), 3.2))
    for ax, t in zip(axes, steps):
        Xt = my_noisy(DATA, eps, ABAR[t])
        print(f"  step {t:>2}: signal kept √abar = {np.sqrt(ABAR[t]):.3f}   average distance to the spiral {distance_to_spiral(Xt[:600]).mean():.3f}")
        ax.scatter(Xt[:, 0], Xt[:, 1], s=2, color="#26324a")
        ax.set_title(f"step {t}"); ax.set_xlim(-3.5, 3.5); ax.set_ylim(-3.5, 3.5); ax.set_xticks([]); ax.set_yticks([])
    plt.tight_layout(); plt.savefig("figures/01_forward.png", dpi=110); plt.show()


# ============================================================ Exercise 2 · learn to undo it
def _temb(t):
    t = np.asarray(t, float)[:, None] / T
    f = np.array([1, 2, 4, 8])[None, :] * np.pi
    return np.concatenate([np.sin(f * t), np.cos(f * t)], 1)


class Denoiser:
    """A small network that looks at a noisy point and the step number, and guesses the noise."""

    def __init__(self, seed=0):
        rng = np.random.default_rng(seed)
        sizes = [10, 128, 128, 2]
        self.W = [rng.normal(0, np.sqrt(2 / m), (m, n)) for m, n in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros((1, n)) for n in sizes[1:]]
        self.losses = []

    def _fwd(self, inp):
        h, z = [inp], []
        for i in range(3):
            zi = h[-1] @ self.W[i] + self.b[i]
            z.append(zi)
            h.append(zi if i == 2 else np.maximum(0, zi))
        return h, z

    def guess(self, xt, t):
        return self._fwd(np.c_[xt, _temb(np.broadcast_to(t, (len(xt),)))])[0][-1]

    def train(self, steps=5000, seed=0, loss_fn=None):
        rng = np.random.default_rng(seed)
        params = self.W + self.b
        m = [np.zeros_like(p) for p in params]
        v = [np.zeros_like(p) for p in params]
        for k in range(1, steps + 1):
            idx = rng.integers(0, len(DATA), 256)
            t = rng.integers(0, T, 256)
            eps = rng.normal(size=(256, 2))
            xt = np.sqrt(ABAR[t])[:, None] * DATA[idx] + np.sqrt(1 - ABAR[t])[:, None] * eps
            h, z = self._fwd(np.c_[xt, _temb(t)])
            err = h[-1] - eps
            self.losses.append(float(loss_fn(eps, h[-1])) if loss_fn else float((err ** 2).mean()))
            d = 2 * err / err.size
            g = [None] * 6
            for i in reversed(range(3)):
                g[i] = h[i].T @ d
                g[3 + i] = d.sum(0, keepdims=True)
                if i > 0:
                    d = (d @ self.W[i].T) * (z[i - 1] > 0)
            for P, gi, mi, vi in zip(params, g, m, v):
                mi *= 0.9; mi += 0.1 * gi
                vi *= 0.999; vi += 0.001 * gi * gi
                P -= 2e-3 * (mi / (1 - 0.9 ** k)) / (np.sqrt(vi / (1 - 0.999 ** k)) + 1e-8)
        return self


def check_my_loss(my_loss):
    print("Check: my_loss")
    e, g = np.array([[1.0, 0.0], [0.0, 3.0]]), np.array([[0.0, 0.0], [0.0, 1.0]])
    try:
        got = my_loss(e, g)
    except Exception as ex:
        _no(f"my_loss raised {type(ex).__name__}: {ex}")
        return
    if got is None:
        _no("my_loss returns None. Replace None with your line.")
        return
    if abs(float(got) - 1.25) > 1e-9:
        hint = " Square each miss before averaging." if abs(float(got) - 0.75) < 1e-9 else ""
        _no(f"for these numbers the average squared miss is (1 + 0 + 0 + 4) ÷ 4 = 1.25; yours is {float(got):.3f}.{hint}")
        return
    _ok("my_loss = 1.25 for the test numbers")
    _ok(f"guessing zero noise every time scores {float(my_loss(np.random.default_rng(0).normal(size=(10000, 2)), np.zeros((10000, 2)))):.2f} (about 1)")
    print("  All correct.")


MODEL = None


def train_denoiser(my_loss, steps=5000):
    global MODEL
    try:
        assert my_loss(np.ones((2, 2)), np.zeros((2, 2))) is not None
    except Exception:
        _finish(2)
        return
    t0 = time.perf_counter()
    MODEL = Denoiser().train(steps, loss_fn=my_loss)
    L = MODEL.losses
    print(f"Printout B: the denoiser, trained for {steps:,} steps in {time.perf_counter() - t0:.1f} s")
    print(f"  average squared miss, first 100 steps: {np.mean(L[:100]):.3f}")
    print(f"  average squared miss, last 500 steps:  {np.mean(L[-500:]):.3f}")
    print("  (guessing zero noise every time would score about 1.0)")
    plt.figure(figsize=(6, 3.2)); plt.plot(np.convolve(L, np.ones(50) / 50, mode="valid"), color="#26324a")
    plt.xlabel("training step"); plt.ylabel("squared miss"); plt.tight_layout(); plt.savefig("figures/02_loss.png", dpi=110); plt.show()


# ============================================================ Exercise 3 · generate
SAMPLES = None


def generate(n=1000, seed=2, show=True):
    global SAMPLES
    if MODEL is None:
        print("  ✗ Train the denoiser first (Exercise 2), then run this cell again.")
        return
    rng = np.random.default_rng(seed)
    x = rng.normal(size=(n, 2))
    snaps = {}
    for t in reversed(range(T)):
        e = MODEL.guess(x, t)
        x = (x - BETAS[t] / np.sqrt(1 - ABAR[t]) * e) / np.sqrt(ALPHAS[t])
        if t > 0:
            x = x + np.sqrt(BETAS[t]) * rng.normal(size=x.shape)
        if t in (49, 30, 15, 5, 0):
            snaps[t] = x.copy()
    SAMPLES = x
    if show:
        fig, axes = plt.subplots(1, 5, figsize=(16, 3.2))
        for ax, t in zip(axes, (49, 30, 15, 5, 0)):
            ax.scatter(snaps[t][:, 0], snaps[t][:, 1], s=2, color="#a8640a")
            ax.set_title(f"step {t}"); ax.set_xlim(-3.5, 3.5); ax.set_ylim(-3.5, 3.5); ax.set_xticks([]); ax.set_yticks([])
        plt.tight_layout(); plt.savefig("figures/03_reverse.png", dpi=110); plt.show()
    return x


def inspect_samples():
    if SAMPLES is None:
        print("  ✗ Generate samples first (the cell above), then run this cell again.")
        return
    noise = np.random.default_rng(3).normal(size=(1000, 2))
    print("Table C: average distance to the spiral")
    print(f"  pure noise (where generation starts): {distance_to_spiral(noise).mean():.3f}")
    print(f"  your generated points:                {distance_to_spiral(SAMPLES).mean():.3f}")
    print(f"  the real training points:             {distance_to_spiral(DATA[:1000]).mean():.3f}")
    near = np.sqrt(((SAMPLES[:, None, :] - DATA[None]) ** 2).sum(-1)).min(1)
    real = np.sort(np.sqrt(((DATA[:500, None] - DATA[None]) ** 2).sum(-1)), 1)[:, 1]
    print("Table D: new points, or copies?")
    print(f"  generated point → nearest training point, on average: {near.mean():.3f}")
    print(f"  training point  → nearest other training point:       {real.mean():.3f}")
    print(f"  generated points that sit on top of a training point (closer than 0.005): {np.mean(near < 0.005):.1%}")


# ============================================================ Exercise 4 · roll downhill, with a little shaking
def energy(x):
    return 2 * (x ** 2 - 1) ** 2


def energy_slope(x):
    return 8 * x * (x ** 2 - 1)


def check_my_langevin(my_langevin_step):
    print("Check: my_langevin_step")
    try:
        got = my_langevin_step(np.array([1.5]), np.array([10.0]), 0.01, np.array([1.0]))
    except Exception as e:
        _no(f"my_langevin_step raised {type(e).__name__}: {e}")
        return
    if got is None:
        _no("my_langevin_step returns None. Replace None with your line.")
        return
    want = 1.5 - 0.01 * 10.0 + np.sqrt(2 * 0.01) * 1.0
    if not np.allclose(got, want):
        hint = " Go downhill: subtract the slope." if np.allclose(got, 1.5 + 0.01 * 10.0 + np.sqrt(0.02)) else ""
        _no(f"x = 1.5, slope 10, step 0.01, shake 1: the answer is {want:.4f}; yours is {float(np.ravel(got)[0]):.4f}.{hint}")
        return
    _ok(f"one step from 1.5: {want:.4f}")
    print("  All correct.")


def langevin(my_langevin_step, n=5000, steps=500, step=0.01):
    try:
        assert my_langevin_step(np.zeros(1), np.zeros(1), 0.01, np.zeros(1)) is not None
    except Exception:
        _finish(4)
        return
    rng = np.random.default_rng(4)
    x = rng.uniform(-3, 3, n)
    for _ in range(steps):
        x = my_langevin_step(x, energy_slope(x), step, rng.normal(size=n))
    g = np.linspace(-3, 3, 20001)
    p = np.exp(-energy(g)); p /= p.sum()
    print(f"Printout E: {n:,} points, {steps} steps of rolling downhill with a little shaking")
    print(f"  share in the left valley: {np.mean(x < 0):.1%}   share in the right valley: {np.mean(x > 0):.1%}")
    print(f"  average distance from 0: {np.abs(x).mean():.3f}   (exact, from p ∝ e^(−E): {(np.abs(g) * p).sum():.3f})")
    fig, ax = plt.subplots(figsize=(6.5, 3.4))
    ax.hist(x, bins=60, density=True, color="#a8640a", alpha=0.7, label="your samples")
    ax.plot(g, p / (g[1] - g[0]), color="#26324a", lw=2.5, label="exact")
    ax.legend(); plt.tight_layout(); plt.savefig("figures/04_langevin.png", dpi=110); plt.show()


# ============================================================ Exercise 5 · layers as steps; learn the rule of motion
A_TRUE = np.array([[0.0, 1.0], [-4.0, -0.3]])        # a damped spring: position and speed


def _exact(t, h0=(1.0, 0.0)):
    from scipy.linalg import expm
    return expm(A_TRUE * t) @ np.asarray(h0)


def check_my_euler(my_euler_step):
    print("Check: my_euler_step")
    f = lambda h: np.array([h[1], -h[0]])
    try:
        got = my_euler_step(np.array([1.0, 2.0]), f, 0.1)
    except Exception as e:
        _no(f"my_euler_step raised {type(e).__name__}: {e}")
        return
    if got is None:
        _no("my_euler_step returns None. Replace None with your line.")
        return
    if not np.allclose(got, [1.2, 1.9]):
        _no(f"from (1, 2) with f(h) = (h₂, −h₁) and dt = 0.1 the answer is (1.2, 1.9); yours is {np.round(np.asarray(got), 3).tolist()}.")
        return
    _ok("one step from (1, 2): (1.2, 1.9)")
    print("  All correct: that is exactly what one residual layer does, h + f(h), with a step size.")


def layers_as_steps(my_euler_step, counts=(20, 50, 100, 500)):
    try:
        assert my_euler_step(np.zeros(2), lambda h: h, 0.1) is not None
    except Exception:
        _finish(5)
        return
    target = _exact(5.0)
    print("Printout F: following the spring for 5 seconds in N steps (N 'layers')")
    for n in counts:
        h = np.array([1.0, 0.0])
        for _ in range(n):
            h = my_euler_step(h, lambda s: A_TRUE @ s, 5.0 / n)
        print(f"  {n:>4} steps: end point off by {np.abs(h - target).max():.3f}")


def learn_rule():
    rng = np.random.default_rng(0)
    obs_t = np.arange(0, 5, 0.1)
    obs = np.array([_exact(t) for t in obs_t]) + rng.normal(0, 0.02, (len(obs_t), 2))
    D = (obs[2:] - obs[:-2]) / 0.2
    H = obs[1:-1]
    A_hat = np.linalg.lstsq(H, D, rcond=None)[0].T
    from scipy.linalg import expm
    ts = np.arange(0, 15, 0.05)
    truth = np.array([_exact(t) for t in ts])
    rule = np.array([expm(A_hat * t) @ obs[0] for t in ts])
    poly = np.polyval(np.polyfit(obs_t, obs[:, 0], 7), ts)
    late = ts > 5
    print("Table G: 5 seconds of a damped spring observed; predict the next 10")
    print(f"  the true rule of motion:    {np.round(A_TRUE, 2).tolist()}")
    print(f"  the rule learned from data: {np.round(A_hat, 2).tolist()}")
    print(f"  average error after 5 s, using the learned rule:  {np.abs(rule[late, 0] - truth[late, 0]).mean():.3f}")
    print(f"  average error after 5 s, using a fitted curve:    {np.abs(poly[late] - truth[late, 0]).mean():,.0f}")
    fig, ax = plt.subplots(figsize=(8, 3.6))
    ax.plot(ts, truth[:, 0], color="#26324a", lw=2.5, label="truth")
    ax.plot(ts, rule[:, 0], color="#a8640a", lw=2.5, ls="--", label="learned rule")
    ax.plot(ts, np.clip(poly, -3, 3), color="#a3291c", lw=2, label="fitted curve (clipped)")
    ax.scatter(obs_t, obs[:, 0], s=10, color="#1f5fa8", label="observed")
    ax.axvline(5, color="grey", ls=":"); ax.set_ylim(-1.6, 1.6); ax.legend(loc="upper right")
    plt.tight_layout(); plt.savefig("figures/05_rule.png", dpi=110); plt.show()


# ============================================================ Exercise 6 · build the symmetry in
def ring(n, seed, angle_lo, angle_hi):
    rng = np.random.default_rng(seed)
    r = np.where(rng.random(n) < 0.5, rng.uniform(0.2, 1.0, n), rng.uniform(1.4, 2.0, n))
    a = rng.uniform(angle_lo, angle_hi, n)
    return np.c_[r * np.cos(a), r * np.sin(a)], (r > 1.2).astype(int)


def check_my_radius(my_radius):
    print("Check: my_radius")
    try:
        got = my_radius(np.array([[3.0, 4.0], [0.0, -2.0]]))
    except Exception as e:
        _no(f"my_radius raised {type(e).__name__}: {e}")
        return
    if got is None:
        _no("my_radius returns None. Replace None with your line.")
        return
    got = np.asarray(got, float).reshape(-1)
    if not np.allclose(got, [5.0, 2.0]):
        _no(f"(3, 4) is 5 from the centre and (0, −2) is 2; yours gives {np.round(got, 3).tolist()}.")
        return
    _ok("(3, 4) → 5 and (0, −2) → 2")
    print("  All correct: turning a point around the centre does not change its distance.")


def symmetry(my_radius):
    try:
        assert my_radius(np.ones((2, 2))) is not None
    except Exception:
        _finish(6)
        return
    from sklearn.linear_model import LogisticRegression
    from sklearn.neural_network import MLPClassifier
    Xtr, ytr = ring(600, 0, 0, np.pi / 2)
    Xq, yq = ring(1000, 1, 0, np.pi / 2)
    Xte, yte = ring(2000, 2, np.pi / 2, 2 * np.pi)
    mlp = MLPClassifier((32, 32), max_iter=2000, random_state=0).fit(Xtr, ytr)
    R = lambda X: np.asarray(my_radius(X), float).reshape(-1, 1)
    lr = LogisticRegression().fit(R(Xtr), ytr)
    print("Table H: inner ring or outer ring? Trained on one quarter of the circle only")
    print(f"  {'':<36} {'same quarter':>13} {'other three quarters':>21}")
    print(f"  {'network on the raw (x, y)':<36} {mlp.score(Xq, yq):>13.1%} {mlp.score(Xte, yte):>21.1%}")
    print(f"  {'one number: distance from the centre':<36} {lr.score(R(Xq), yq):>13.1%} {lr.score(R(Xte), yte):>21.1%}")


# ============================================================ Exercise 5, change one thing · a wrong rule
def wrong_rule():
    """Tell the model the spring has no friction (wrong), and learn only its stiffness from the data."""
    from scipy.linalg import expm
    rng = np.random.default_rng(0)
    obs_t = np.arange(0, 5, 0.1)
    obs = np.array([_exact(t) for t in obs_t]) + rng.normal(0, 0.02, (len(obs_t), 2))
    D = (obs[2:] - obs[:-2]) / 0.2
    H = obs[1:-1]
    k_hat = -np.sum(D[:, 1] * H[:, 0]) / np.sum(H[:, 0] ** 2)
    A_wrong = np.array([[0.0, 1.0], [-k_hat, 0.0]])
    A_hat = np.linalg.lstsq(H, D, rcond=None)[0].T
    ts = np.arange(0, 15, 0.05)
    truth = np.array([_exact(t) for t in ts])
    wrong = np.array([expm(A_wrong * t) @ obs[0] for t in ts])
    learned = np.array([expm(A_hat * t) @ obs[0] for t in ts])
    late = ts > 5
    e_w = np.abs(wrong[late, 0] - truth[late, 0]).mean()
    e_l = np.abs(learned[late, 0] - truth[late, 0]).mean()
    print("Printout G2: the same 5 seconds, but the model is told 'no friction' (the real spring has some)")
    print(f"  average error after 5 s, rule learned freely:     {e_l:.3f}")
    print(f"  average error after 5 s, told the wrong rule:     {e_w:.3f}   ({e_w / e_l:.0f} times worse)")
    fig, ax = plt.subplots(figsize=(8, 3.4))
    ax.plot(ts, truth[:, 0], color="#26324a", lw=2.5, label="truth")
    ax.plot(ts, wrong[:, 0], color="#a3291c", lw=2.2, ls="--", label="told 'no friction'")
    ax.axvline(5, color="grey", ls=":"); ax.legend(loc="upper right")
    plt.tight_layout(); plt.savefig("figures/05b_wrong_rule.png", dpi=110); plt.show()


# ============================================================ Exercise 6, change one thing · a false symmetry
def _ring_by_angle(n, seed):
    rng = np.random.default_rng(seed)
    r = rng.uniform(0.5, 2.0, n)
    a = rng.uniform(0, 2 * np.pi, n)
    X = np.c_[r * np.cos(a), r * np.sin(a)]
    return X, (X[:, 1] > 0).astype(int)


def false_symmetry(my_radius):
    try:
        assert my_radius(np.ones((2, 2))) is not None
    except Exception:
        _finish(6)
        return
    from sklearn.linear_model import LogisticRegression
    from sklearn.neural_network import MLPClassifier
    Xte, yte = _ring_by_angle(3000, 1)
    R = lambda X: np.asarray(my_radius(X), float).reshape(-1, 1)
    print("Table H2: a new question, top half or bottom half? (the answer now depends on the angle)")
    print(f"  {'training points':>16} {'network on raw (x, y)':>23} {'distance from the centre':>26}")
    for n in (100, 1000, 10000):
        Xtr, ytr = _ring_by_angle(n, 0)
        mlp = MLPClassifier((32, 32), max_iter=2000, random_state=0).fit(Xtr, ytr)
        lr = LogisticRegression().fit(R(Xtr), ytr)
        print(f"  {n:>16,} {mlp.score(Xte, yte):>23.1%} {lr.score(R(Xte), yte):>26.1%}")


# ============================================================ Exercise 7 · choosing
SITUATIONS = [
    ("a", "You want new, realistic examples of a kind of data you already have plenty of."),
    ("b", "You know roughly how a system moves, and you have a short recording of it."),
    ("c", "The answer must not change when the input is turned or reordered, exactly."),
    ("d", "The answer barely changes with small shifts and blur, but not exactly."),
    ("e", "A standard equation on a simple shape, and you need an answer you can trust."),
    ("f", "No reliable rule at all, but plenty of labelled data."),
    ("g", "No measurements at all, but you trust the equation the system obeys."),
]
METHODS = {"1": "ordinary machine learning", "2": "a diffusion model (and check for copies)",
           "3": "a classical solver", "4": "augmentation (Week 9)",
           "5": "learn the rule of motion, keeping what you know", "6": "build the symmetry in",
           "7": "a physics-informed network: let the equation teach"}
_ANSWERS = {"a": "2", "b": "5", "c": "6", "d": "4", "e": "3", "f": "1", "g": "7"}


def show_choices():
    print("Situations:")
    for k, s in SITUATIONS:
        print(f"  ({k}) {s}")
    print("Methods:")
    for k, m in METHODS.items():
        print(f"  [{k}] {m}")


def reveal_choices():
    print("Table I: a reference match")
    for k, s in SITUATIONS:
        print(f"  ({k}) → [{_ANSWERS[k]}] {METHODS[_ANSWERS[k]]}")


# ============================================================ Exercise 7 · zero data: PINN and PIML
# The spring: heaviness m, friction c, stiffness k. It starts at position 1, standing still.
M_, C_, K_ = 1.0, 0.3, 4.0
_rngf = np.random.default_rng(0)
_J = 80
_W = _rngf.normal(0, 2.0, _J)
_B = _rngf.uniform(-10, 10, _J)


def _features(t):
    """A small network with a fixed hidden layer of 80 tanh neurons: the outputs, their speeds and their accelerations."""
    z = _W * np.asarray(t, float)[:, None] + _B
    th = np.tanh(z)
    s2 = 1 - th ** 2
    return th, _W * s2, -2 * _W ** 2 * th * s2


def _guess_parts(t, start_built_in=True):
    """The guess u(t) = start + t² × network(t), so u(0) = 1 and the starting speed is 0, whatever the network does."""
    t = np.asarray(t, float)[:, None]
    phi, d1, d2 = _features(t[:, 0])
    n = len(t)
    if not start_built_in:
        return phi, d1, d2, np.zeros(n), np.zeros(n), np.zeros(n)
    U = t ** 2 * phi
    dU = 2 * t * phi + t ** 2 * d1
    ddU = 2 * phi + 4 * t * d1 + t ** 2 * d2
    return U, dU, ddU, np.ones(n), np.zeros(n), np.zeros(n)


def _spring_exact(ts, c=C_, k=K_):
    from scipy.linalg import expm
    A = np.array([[0.0, 1.0], [-k / M_, -c / M_]])
    return np.array([expm(A * t) @ np.array([1.0, 0.0]) for t in np.atleast_1d(ts)])[:, 0]


def check_my_leftover(my_leftover):
    print("Check: my_leftover")
    tests = [((1.0, 0.0, -4.0), (1, 0.3, 4), 0.0), ((1.0, 0.0, 0.0), (1, 0.3, 4), 4.0), ((0.5, 2.0, 1.0), (2, 0.5, 3), 4.5)]
    for (u, du, ddu), (m, c, k), want in tests:
        try:
            got = my_leftover(u, du, ddu, m, c, k)
        except Exception as e:
            _no(f"my_leftover raised {type(e).__name__}: {e}")
            return
        if got is None:
            _no("my_leftover returns None. Replace None with your line.")
            return
        if abs(float(got) - want) > 1e-9:
            _no(f"position {u}, speed {du}, change of speed {ddu}, with m={m}, c={c}, k={k}: the leftover is {want}; yours is {float(got)}.")
            return
        _ok(f"u={u}, u'={du}, u''={ddu}: leftover {want}" + ("   (obeys the rule)" if want == 0 else ""))
    print("  All correct: a leftover of 0 means the guess obeys the rule.")


def _solve(my_leftover, checkpoints, c_told, start_built_in, T=10.0):
    tc = np.linspace(0, T, checkpoints)
    U, dU, ddU, u0, du0, ddu0 = _guess_parts(tc, start_built_in)
    Mx = my_leftover(U, dU, ddU, M_, c_told, K_)
    rhs = -my_leftover(u0, du0, ddu0, M_, c_told, K_)
    v = np.linalg.lstsq(Mx, rhs, rcond=None)[0]
    score = float(np.mean((Mx @ v - rhs) ** 2))
    tt = np.linspace(0, T, 2000)
    Ut, _, _, u0t, _, _ = _guess_parts(tt, start_built_in)
    return score, tt, Ut @ v + u0t


def zero_data(my_leftover, checkpoints=200, start_built_in=True, c_told=C_):
    try:
        assert my_leftover(1.0, 0.0, 0.0, 1, 0.3, 4) is not None
    except Exception:
        _finish(7)
        return
    score, tt, pred = _solve(my_leftover, checkpoints, c_told, start_built_in)
    truth = _spring_exact(tt)
    late = tt > 4
    print(f"Printout J: a network taught only by the rule ({checkpoints} checkpoints, zero measurements"
          + ("" if start_built_in else ", start NOT built in") + (f", told friction {c_told}" if c_told != C_ else "") + ")")
    print(f"  its score (average leftover², at the checkpoints): {score:.1e}")
    print(f"  its real error over 10 s:                           {np.abs(pred - truth).mean():.4f}")
    print(f"  its real error after 4 s:                           {np.abs(pred[late] - truth[late]).mean():.4f}")
    if checkpoints == 200 and start_built_in and c_told == C_:
        rng = np.random.default_rng(0)
        td = np.linspace(0, 4, 40)
        yd = _spring_exact(td) + rng.normal(0, 0.02, 40)
        phi = _features(td)[0]
        v = np.linalg.solve(phi.T @ phi + 1e-3 * np.eye(_J), phi.T @ yd)
        pd = _features(tt)[0] @ v
        print("  For comparison, the same network fitted to 40 real measurements from the first 4 s:")
        print(f"  its real error after 4 s:                           {np.abs(pd[late] - truth[late]).mean():.4f}")
        fig, ax = plt.subplots(figsize=(8, 3.4))
        ax.plot(tt, truth, color="#26324a", lw=2.5, label="truth")
        ax.plot(tt, pred, color="#a8640a", lw=2.2, ls="--", label="taught by the rule (0 data)")
        ax.plot(tt, np.clip(pd, -1.5, 1.5), color="#a3291c", lw=2, label="taught by 40 measurements")
        ax.scatter(td, yd, s=10, color="#1f5fa8"); ax.axvline(4, color="grey", ls=":"); ax.set_ylim(-1.5, 1.5)
        ax.legend(loc="lower right", fontsize=8); plt.tight_layout(); plt.savefig("figures/07_zero_data.png", dpi=110); plt.show()


def find_friction(seed=3):
    """Physics-informed ML (elective E5): the equation is known, one number in it (the friction) is not.
    Simulate the spring for every candidate friction and keep the one that best matches 20 noisy readings."""
    rng = np.random.default_rng(seed)
    td = np.linspace(0, 6, 20)
    yd = _spring_exact(td) + rng.normal(0, 0.03, 20)
    cs = np.linspace(0, 1, 1001)
    errs = [np.mean((_spring_exact(td, c=c) - yd) ** 2) for c in cs]
    c_hat = cs[int(np.argmin(errs))]
    hats = []
    for s in range(30):
        r = np.random.default_rng(100 + s)
        y = _spring_exact(td) + r.normal(0, 0.03, 20)
        e = [np.mean((_spring_exact(td, c=c) - y) ** 2) for c in cs[::5]]
        hats.append(cs[::5][int(np.argmin(e))])
    lo, hi = np.percentile(hats, [2.5, 97.5])
    print("Printout K: the unknown friction, found with the simulator and 20 noisy readings")
    print(f"  your 20 readings give: {c_hat:.2f}   (the true friction is {C_})")
    print(f"  over 30 repeats with fresh noise, 95% of the answers lie between {lo:.2f} and {hi:.2f}")
