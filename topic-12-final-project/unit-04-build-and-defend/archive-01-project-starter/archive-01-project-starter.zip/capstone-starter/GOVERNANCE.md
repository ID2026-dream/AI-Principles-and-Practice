# Governance note

## Purpose and setting
<The decision this model would support, who would use it, and who would be affected by it.>

## Data protection
<Personal data involved, its legal basis under GDPR, and how it was protected during the project.
For E5 and E6: state that no personal data is involved.>

## EU AI Act
<The risk tier this system would fall into if deployed, and why.>

## Human oversight
<Who reviews the model's outputs, and when a person must make the decision instead.>

## Monitoring and failure
<What would show that the model has stopped working, and what should happen then.>
