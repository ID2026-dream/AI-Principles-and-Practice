# Logbook

Write an entry whenever you make a decision, run an experiment, hit a dead end or fix
something, on the day it happens. Short is fine; honest is essential. This is marking
element M5, and it is what the interview questions are drawn from.

## Entry template

### <date> · <one-line title>

- **What I did:**
- **What happened:** (numbers, with the file in `outputs/` that shows them)
- **What I decided, and why:**
- **What I will do next:**

---

## Use of AI tools

One row each time you use an AI tool for this project.

| Date | Tool | What I asked | What I used | What I changed or checked |
|---|---|---|---|---|
| | | | | |

---

<!-- your entries below, newest last -->
