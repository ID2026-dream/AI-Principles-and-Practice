# Model card

## Model details
<What the model is, its architecture, how it was trained, and the version (git tag) this card describes.>

## Intended use
<Who should use it, for what decision, and what it must not be used for.>

## Data
<The assigned data: what it contains, how it was split, what is missing, and who is not represented.
In E5 and E6, the equations and your personal variant.>

## Performance
<Headline metrics on held-out data, against the baseline.>

## Performance for whom (or where)
<Metrics for each group you audited (E1 to E4), or for each operating regime or region of the domain (E5, E6).>

## Mitigation and its cost
<The one mitigation you applied, what it changed, and who bears its cost.>

## Explanations
<What drives the model's decisions (SHAP or LIME; in E5 and E6, learned physical parameters or residual maps), and where the explanations should not be trusted.>

## Limitations
<Where the model fails, and the conditions outside which it must not be used.>
