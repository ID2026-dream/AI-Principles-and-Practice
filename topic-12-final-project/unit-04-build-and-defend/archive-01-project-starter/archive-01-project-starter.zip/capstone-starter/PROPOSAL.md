# Proposal

Replace this file with the `PROPOSAL.md` you received after submitting the capstone proposal
form. Keep it up to date: if your plan changes, edit it here and record why in `LOGBOOK.md`.
