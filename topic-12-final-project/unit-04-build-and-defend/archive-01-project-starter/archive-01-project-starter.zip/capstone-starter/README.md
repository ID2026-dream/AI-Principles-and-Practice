# <Your project title>

**AI Principles and Practice · Capstone Project · Elective <E1 to E6>**
<Your name> · <student number>

> Replace everything in angle brackets. Keep the headings: the lecturers read this file first.

## The question

<The one-sentence question from your proposal.>

## How to reproduce every result

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m pytest -q          # the from-scratch components and their tests (D5)
python reproduce.py          # every table and figure, written to outputs/
```

Put the assigned data in `data/` first (see `data/README.md`). From a clean clone, these
commands must reproduce every number in this README: that is what marking element M2 checks.

## Results

<A short table of your headline results on held-out data, baseline against main model,
and the figure that shows them best. Every number here must come from `outputs/`.>

## What is where

| Path | What it is |
|---|---|
| `report/` | Your report (D1): write it from `report/latex/` or `report/word/`, and keep the PDF here too |
| `PROPOSAL.md` | Your approved proposal and implementation plan |
| `LOGBOOK.md` | Decisions, experiments, dead ends and fixes, and your use of AI tools (D3) |
| `src/scratch/` | Your backpropagation, optimiser steps and PCA via SVD (D5) |
| `tests/` | The tests for `src/scratch/`, against numerical differentiation and reference libraries |
| `src/` | Data preparation, training, evaluation and the audit |
| `reproduce.py` | One command for every result |
| `MODEL_CARD.md` | What the model is for, how it performs for whom, and its limits (D8) |
| `GOVERNANCE.md` | The rules that apply and how the risks are handled (D8) |
| `outputs/` | Generated tables and figures (not committed) |

## Submitting

By **23:59 on Wednesday 6 January 2027**:

1. Upload your report as a PDF to Moodle.
2. Put the same PDF and its source (LaTeX or Word) in `report/`, tag the commit you want marked as
   `final`, and push the tag:

   ```bash
   git tag final && git push origin final
   ```

Then come to your 10-minute in-person interview in the week of 11 January 2027: be ready to show
one key result running from this repository.
