# Data

Put your assigned data here. Everything in this folder except this file is ignored by git:
**never commit the data** (it is not public, and some of it is personal data).

In E5 and E6 there is no data to download: `src/data.py` generates it from your personal variant.
