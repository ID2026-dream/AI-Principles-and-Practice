# Your report (D1)

Write your capstone project report from one of the two templates. They have the same outline:
the same sections, tables and appendices.

- **LaTeX:** `latex/capstone-report.tex`. Build with `latexmk -pdf capstone-report.tex`, or upload
  the `latex/` folder to Overleaf. References go in `latex/references.bib`.
- **Word:** `word/Capstone-Report-Template.docx`. Update the contents table before you export
  (right-click it, then **Update Field**).

Replace the grey guidance text as you write each section, then delete it. The main body should be
about 5,000 words (between 4,000 and 6,000), not counting the title page, abstract, references
and appendices.

When you submit, export the report as a PDF and keep that PDF here as well as uploading it to
Moodle. Every result in the report must link to where it is produced in this repository, at the
commit tagged `final`. Appendix A lists every deliverable with its link.
