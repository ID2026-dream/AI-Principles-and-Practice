"""Reproduce every result in this repository with one command:

    python reproduce.py

It runs the four steps in order and writes every table and figure to outputs/.
Keep it working from a clean clone: this is what marking element M2 checks.
"""
from pathlib import Path

from src import audit, data, evaluate, train

CONFIG = {
    "seed": 0,           # fix every random seed from this one number
    "data_dir": "data",
    "out_dir": "outputs",
}


def main():
    Path(CONFIG["out_dir"]).mkdir(exist_ok=True)
    print("1/4  preparing the data")
    prepared = data.load_and_prepare(CONFIG)
    print("2/4  training the models")
    models = train.train_models(prepared, CONFIG)
    print("3/4  evaluating on held-out data")
    evaluate.evaluate_models(models, prepared, CONFIG)
    print("4/4  audit, mitigation and explanations")
    audit.run_audit(models, prepared, CONFIG)
    print(f"Done. Results are in {CONFIG['out_dir']}/")


if __name__ == "__main__":
    main()
