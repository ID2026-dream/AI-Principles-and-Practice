"""Step 4: the fairness (or reliability) audit, one mitigation and its measured cost, and the explanations."""


def run_audit(models, prepared, config):
    """Measure the audit metrics from your proposal, apply one mitigation, measure its cost,
    and produce the explainability summary. Save tables and figures to outputs/."""
    raise NotImplementedError("Write run_audit for your elective.")
