"""Step 1: load and prepare the assigned data (or, in E5 and E6, generate it)."""


def load_and_prepare(config):
    """Read the data from data/, clean it, and split it without leakage.

    Return whatever the next steps need, for example a dict of training and test arrays.
    """
    raise NotImplementedError("Write load_and_prepare for your elective.")
