"""Step 3: evaluate on held-out data and save the results tables and figures to outputs/."""


def evaluate_models(models, prepared, config):
    """Compute the metrics from your proposal on the held-out data. Return a results table."""
    raise NotImplementedError("Write evaluate_models for your elective.")
