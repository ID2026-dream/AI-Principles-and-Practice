"""Your from-scratch components: backpropagation, optimiser steps and PCA via SVD."""
