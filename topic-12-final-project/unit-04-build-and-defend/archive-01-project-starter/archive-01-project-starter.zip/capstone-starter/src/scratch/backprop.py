"""Backpropagation, written by you (deliverable D5, marking element M3).

A small fully connected network: ReLU on every hidden layer, nothing on the last layer.
Keep these four signatures: tests/test_backprop.py checks them against numerical
differentiation. Your Week 7 lab code is the place to start.
"""
import numpy as np


def init_mlp(sizes, seed=0):
    """Random weights scaled to each layer's size (He initialisation) and zero biases.

    sizes: layer widths, for example [2, 16, 16, 1].
    Returns (W, b): W[i] has shape (sizes[i], sizes[i+1]); b[i] has shape (1, sizes[i+1]).
    """
    raise NotImplementedError("Write init_mlp: see its docstring.")


def forward(X, W, b):
    """The forward pass. X has shape (n, sizes[0]).

    Returns (h, z): h[0] is X, h[i+1] is the output of layer i (ReLU on hidden layers,
    no activation on the last), and z[i] is layer i's weighted sum before the activation.
    """
    raise NotImplementedError("Write forward: see its docstring.")


def backward(h, z, W, grad_out):
    """The backward pass. grad_out is dL/d(output), the same shape as h[-1].

    Returns (gW, gb): the gradient of the loss for every W[i] and b[i], same shapes.
    The three rules: a weight's blame = what came in x blame going out; hand the blame
    back through the same weights; nothing passes back through a switched-off neuron.
    """
    raise NotImplementedError("Write backward: see its docstring.")


def input_gradient(h, z, W, grad_out):
    """dL/dX: the gradient of the loss with respect to the network's inputs, shape like h[0].

    Needed in elective E6 (the equation's derivatives are taken with respect to the inputs).
    Optional in the other electives: its test is skipped while this raises NotImplementedError.
    """
    raise NotImplementedError("Write input_gradient if you are taking E6.")
