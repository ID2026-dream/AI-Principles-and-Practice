"""Optimiser steps, written by you (deliverable D5, marking element M3).

Both functions change the parameter arrays in place and return the state to pass in next
time. tests/test_optimiser.py checks them against known values (and against PyTorch, if it
is installed). Use at least one of them to train your own network in the project.
"""
import numpy as np


def sgd_step(params, grads, lr, momentum=0.0, state=None):
    """Stochastic gradient descent, with optional momentum (PyTorch's convention).

    For each parameter p with gradient g:  v = momentum * v + g;  p = p - lr * v.
    With momentum 0 this is simply p = p - lr * g. state holds the velocities v
    (create them, as zeros, when state is None). Returns state.
    """
    raise NotImplementedError("Write sgd_step: see its docstring.")


def adam_step(params, grads, state=None, lr=1e-3, beta1=0.9, beta2=0.999, eps=1e-8):
    """Adam, with bias correction.

    For each parameter p with gradient g, at step t (counting from 1):
      m = beta1 * m + (1 - beta1) * g
      v = beta2 * v + (1 - beta2) * g**2
      m_hat = m / (1 - beta1**t);  v_hat = v / (1 - beta2**t)
      p = p - lr * m_hat / (sqrt(v_hat) + eps)
    state holds m, v and t (create them when state is None). Returns state.
    """
    raise NotImplementedError("Write adam_step: see its docstring.")
