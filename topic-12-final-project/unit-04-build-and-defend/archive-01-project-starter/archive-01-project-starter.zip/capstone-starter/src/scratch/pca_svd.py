"""PCA via the SVD, written by you (deliverable D5, marking element M3).

tests/test_pca_svd.py checks it against scikit-learn. Your Week 8 lab code is the
place to start.
"""
import numpy as np


def pca(X, k):
    """Principal component analysis of X (n samples x d features) by the singular value decomposition.

    Centre each column, take the SVD of the centred data, and return:
      components         (k, d)  the top-k principal directions, one per row, unit length
      explained_variance (k,)    the variance along each direction (divide by n - 1, as scikit-learn does)
      scores             (n, k)  the centred data projected onto the components
    """
    raise NotImplementedError("Write pca: see its docstring.")
