"""Step 2: train the baseline and the main model, saving loss and metric curves to outputs/."""


def train_models(prepared, config):
    """Train your baseline and your main model. Return the trained models and their training history."""
    raise NotImplementedError("Write train_models for your elective.")
