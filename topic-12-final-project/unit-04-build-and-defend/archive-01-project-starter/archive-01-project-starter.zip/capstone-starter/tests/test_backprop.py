"""Checks your backpropagation against numerical differentiation (and PyTorch, if installed).

Run with:  python -m pytest -q
"""
import numpy as np
import pytest

from src.scratch.backprop import backward, forward, init_mlp, input_gradient

SIZES = [3, 8, 6, 2]


def _setup(seed=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(7, SIZES[0]))
    Y = rng.normal(size=(7, SIZES[-1]))
    W, b = init_mlp(SIZES, seed=1)
    return X, Y, W, b


def _loss(X, Y, W, b):
    out = forward(X, W, b)[0][-1]
    return float(np.mean((out - Y) ** 2))


def _grad_out(X, Y, W, b):
    out = forward(X, W, b)[0][-1]
    return 2 * (out - Y) / out.size


def test_init_shapes():
    W, b = init_mlp(SIZES, seed=0)
    assert [w.shape for w in W] == [(3, 8), (8, 6), (6, 2)]
    assert [x.shape for x in b] == [(1, 8), (1, 6), (1, 2)]
    assert all(np.all(x == 0) for x in b), "biases should start at zero"
    assert np.std(W[0]) > 0, "weights should start random"


def test_forward_shapes_and_relu():
    X, Y, W, b = _setup()
    h, z = forward(X, W, b)
    assert len(h) == len(SIZES) and len(z) == len(SIZES) - 1
    assert h[0] is X or np.allclose(h[0], X)
    assert h[-1].shape == (7, 2)
    for hidden in h[1:-1]:
        assert np.all(hidden >= 0), "hidden layers use ReLU"
    assert np.allclose(h[-1], z[-1]), "the last layer has no activation"


def test_backward_matches_numerical_gradient():
    X, Y, W, b = _setup()
    h, z = forward(X, W, b)
    gW, gb = backward(h, z, W, _grad_out(X, Y, W, b))
    mine = np.concatenate([g.ravel() for g in list(gW) + list(gb)])
    numerical = []
    for P in W + b:
        for idx in np.ndindex(P.shape):
            old = P[idx]
            P[idx] = old + 1e-6; up = _loss(X, Y, W, b)
            P[idx] = old - 1e-6; down = _loss(X, Y, W, b)
            P[idx] = old
            numerical.append((up - down) / 2e-6)
    numerical = np.array(numerical)
    rel = np.linalg.norm(mine - numerical) / (np.linalg.norm(mine) + np.linalg.norm(numerical))
    assert rel < 1e-6, f"relative difference {rel:.2e}: backward does not match numerical differentiation"


def test_input_gradient_matches_numerical_gradient():
    X, Y, W, b = _setup()
    h, z = forward(X, W, b)
    try:
        gX = input_gradient(h, z, W, _grad_out(X, Y, W, b))
    except NotImplementedError:
        pytest.skip("input_gradient is only required in elective E6")
    num = np.zeros_like(X)
    for idx in np.ndindex(X.shape):
        old = X[idx]
        X[idx] = old + 1e-6; up = _loss(X, Y, W, b)
        X[idx] = old - 1e-6; down = _loss(X, Y, W, b)
        X[idx] = old
        num[idx] = (up - down) / 2e-6
    rel = np.linalg.norm(gX - num) / (np.linalg.norm(gX) + np.linalg.norm(num))
    assert rel < 1e-6, f"relative difference {rel:.2e}"


def test_backward_matches_pytorch():
    torch = pytest.importorskip("torch")
    X, Y, W, b = _setup()
    h, z = forward(X, W, b)
    gW, gb = backward(h, z, W, _grad_out(X, Y, W, b))
    tW = [torch.tensor(w, requires_grad=True) for w in W]
    tb = [torch.tensor(x, requires_grad=True) for x in b]
    a = torch.tensor(X)
    for i, (w, x) in enumerate(zip(tW, tb)):
        a = a @ w + x
        if i < len(tW) - 1:
            a = torch.relu(a)
    torch.mean((a - torch.tensor(Y)) ** 2).backward()
    for mine, ref in zip(list(gW) + list(gb), tW + tb):
        assert np.allclose(mine, ref.grad.numpy(), atol=1e-10)
