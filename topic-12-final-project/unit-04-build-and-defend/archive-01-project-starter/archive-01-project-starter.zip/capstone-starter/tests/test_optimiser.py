"""Checks your optimiser steps against known values (and PyTorch, if installed).

Run with:  python -m pytest -q
"""
import numpy as np
import pytest

from src.scratch.optimiser import adam_step, sgd_step

GRADS = ([0.3, -0.1, 2.0], [-0.2, 0.4, 1.0], [0.1, 0.1, -0.5])


def test_sgd_without_momentum():
    p = [np.array([1.0, -2.0, 0.5])]
    sgd_step(p, [np.array(GRADS[0])], lr=0.1)
    assert np.allclose(p[0], [0.97, -1.99, 0.3])


def test_sgd_with_momentum_two_steps():
    p = [np.array([1.0, -2.0, 0.5])]
    state = sgd_step(p, [np.array(GRADS[0])], lr=0.1, momentum=0.9)
    sgd_step(p, [np.array(GRADS[1])], lr=0.1, momentum=0.9, state=state)
    # v1 = g1;  v2 = 0.9 * g1 + g2
    expected = np.array([1.0, -2.0, 0.5]) - 0.1 * np.array(GRADS[0]) - 0.1 * (0.9 * np.array(GRADS[0]) + np.array(GRADS[1]))
    assert np.allclose(p[0], expected)


def test_adam_first_step_moves_each_parameter_by_lr():
    p = [np.array([1.0, -2.0, 0.5])]
    adam_step(p, [np.array(GRADS[0])], lr=0.1)
    # after bias correction the first step is lr * sign(g), whatever the size of g
    assert np.allclose(p[0], [0.9, -1.9, 0.4], atol=1e-6)


def test_adam_three_steps_known_values():
    p = [np.array([1.0, -2.0, 0.5])]
    state = None
    for g in GRADS:
        state = adam_step(p, [np.array(g)], state, lr=0.1)
    assert np.allclose(p[0], [0.85769706, -2.01304487, 0.2504159], atol=1e-7)


def test_adam_minimises_a_bowl():
    p = [np.array([5.0, -4.0])]
    state = None
    for _ in range(3000):
        state = adam_step(p, [2 * (p[0] - 3.0)], state, lr=0.05)
    assert np.allclose(p[0], [3.0, 3.0], atol=1e-3)


def test_adam_matches_pytorch():
    torch = pytest.importorskip("torch")
    p = [np.array([1.0, -2.0, 0.5])]
    tp = torch.tensor([1.0, -2.0, 0.5], dtype=torch.float64, requires_grad=True)
    opt = torch.optim.Adam([tp], lr=0.1)
    state = None
    for g in GRADS:
        state = adam_step(p, [np.array(g)], state, lr=0.1)
        opt.zero_grad(); tp.grad = torch.tensor(g, dtype=torch.float64); opt.step()
    assert np.allclose(p[0], tp.detach().numpy(), atol=1e-10)
