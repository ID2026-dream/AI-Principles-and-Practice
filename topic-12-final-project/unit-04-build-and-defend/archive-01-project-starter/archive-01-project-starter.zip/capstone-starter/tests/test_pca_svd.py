"""Checks your PCA via SVD against scikit-learn.

Run with:  python -m pytest -q
"""
import numpy as np
from sklearn.decomposition import PCA

from src.scratch.pca_svd import pca


def _data():
    rng = np.random.default_rng(0)
    A = rng.normal(size=(200, 5)) @ rng.normal(size=(5, 5)) + 3.0
    return A


def test_shapes():
    comps, var, scores = pca(_data(), 3)
    assert comps.shape == (3, 5) and var.shape == (3,) and scores.shape == (200, 3)


def test_components_are_orthonormal():
    comps, _, _ = pca(_data(), 3)
    assert np.allclose(comps @ comps.T, np.eye(3), atol=1e-10)


def test_matches_scikit_learn():
    X = _data()
    comps, var, scores = pca(X, 3)
    ref = PCA(n_components=3).fit(X)
    assert np.allclose(var, ref.explained_variance_, rtol=1e-8), "explained variance: divide by n - 1"
    for k in range(3):   # a component may point either way: compare up to sign
        s = np.sign(comps[k] @ ref.components_[k])
        assert np.allclose(s * comps[k], ref.components_[k], atol=1e-8)
        assert np.allclose(s * scores[:, k], ref.transform(X)[:, k], atol=1e-8)


def test_variance_is_sorted_and_centring_is_done():
    X = _data()
    _, var, scores = pca(X, 5)
    assert np.all(np.diff(var) <= 1e-12), "largest variance first"
    assert np.allclose(scores.mean(0), 0, atol=1e-10), "centre the data before the SVD"
